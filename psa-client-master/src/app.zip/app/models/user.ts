export class User {
    name: string;
    email: string;
    phonenumber: string;
    company_ID: number;
    role: string;
}