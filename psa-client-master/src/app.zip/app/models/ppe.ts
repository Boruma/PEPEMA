import { Property } from './property';
import { size } from './size';
import { size_range } from './size_range';
import { Time } from '@angular/common';
import {Pe } from './pe'
import { from } from 'rxjs';
import { Role } from './role';
export class PPE {
    //ppe_ID: number;
    pe_ID: number;
    order_ID: number;
    stock_ID: number;
    employee_ID: number;
    pn: number;
    created_at: Date;
    updated_at: Date;

    sn: string;
    commissioningdate: Date;
    comment: string;
    state: string;
    delivered: boolean;
    size_ranges: size_range[];
    properties: Property[];
    //template: Pe;
    pe: Pe;

    //just for testing
    roles : Role[]; 

    constructor() {
        //console.log("constructor PPE")
        this.pe_ID =  0;
        this.order_ID = 0;
        this.stock_ID =  0;
        this.employee_ID = 0;
        this.pn = 0;
        this.created_at = null;
        this.updated_at = null;
    
        this.sn = "";
        this.commissioningdate=  null;
        this.comment = null;
        this.state = null;
        this.delivered = null;
        // this.size_ranges = null;
        // this.properties = null;
        //this.template = null;

        this.properties = new Array<Property>();
        this.size_ranges = new Array<size_range>();
        this.pe = <Pe>{}; //ggf mit new erstellen?
        this.pe.properties = new Array<Property>();
        this.pe.size_ranges = new Array<size_range>();
        this.pe.roles = new Array<Role>();
    }
}