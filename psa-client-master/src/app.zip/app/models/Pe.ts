import { Property } from './property'
import { size_range } from './size_range';
import {Supplier} from './Supplier';
import {Role} from './role';
export class Pe {
    pe_ID:number;
    name: string;
    supplier: Supplier;
    properties: Property[];
    size_ranges: size_range[];
    roles: Role[];
    supplItemID: string;
    
    constructor() {
    }


}