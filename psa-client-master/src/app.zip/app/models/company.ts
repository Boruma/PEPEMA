import { Address } from './address';

export class Company {
    company_ID: number;
    name: string;
    address: Address;
}