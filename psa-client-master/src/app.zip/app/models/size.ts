export class size {
    name: string;
    size_ID: number;
    sizer_ID: number;
}