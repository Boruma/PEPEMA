export class Role {
    role_ID: number;
    name: string;
}