import { size } from './size' 
export class size_range{
    sizer_ID: number;
    name: string;
    sizes: size[];

    constructor(size, range) {
        this.sizer_ID = range.sizer_ID,
        this.name = range.name,
        this.sizes = new Array();
        this.sizes[0] = size;
    }
}