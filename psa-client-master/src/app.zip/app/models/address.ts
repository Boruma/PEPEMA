export class Address {
    place: string;
    street: string;
    housenumber: string;
    postcode: string;
    address_additional: string;
}