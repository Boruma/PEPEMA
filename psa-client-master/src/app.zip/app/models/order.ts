import { Address } from './address';
import { PPE } from './ppe';
import { Role } from './role';
import { Supplier } from './Supplier';


export class Order {

    order_ID: number;
    orderdate: string;  //erstmal als String, müssen irgendwie das passende Format sicherstellen (yyyy-mm-dd)
    expectedDeliveryDate: Date;     //hier auch Format sicherstellen
    commitedDeliveryDate: Date; //Date when all ppes from one order are delivered; hier auch Format sicherstellen
    state: string;  //"null" = orderlist created, 
                    //"orderd" = order is ordered, 
                    //"delivered" = alle ppe from the order are deliverd
    supplier_ID: number;
    // created_at: Date; //wird nicht benutzt
    // updated_at: Date; //wird nicht benutzt
    supplier: Supplier;
    ppes: PPE[];

    constructor(){        
            this.order_ID = null;
        //    this.orderdate = null;
        //    this.expectedDeliveryDate = null;
        //    this.commitedDeliveryDate = null; //only allowd in updateOrder()
            // this.state = null;
            this.supplier_ID = null;
        //    this.created_at = null;
        //    this.updated_at = null;
            this.supplier = null; //new Supplier(supplierId);
            this.ppes = null;
    }

}

