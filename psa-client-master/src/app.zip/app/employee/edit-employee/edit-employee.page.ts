import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-employee-page',
  templateUrl: './edit-employee.page.html',
  styleUrls: ['./edit-employee.page.scss'],
})
export class EditEmployeePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
