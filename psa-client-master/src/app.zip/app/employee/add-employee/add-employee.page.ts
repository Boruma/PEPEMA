import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-employee-page',
  templateUrl: './add-employee.page.html',
  styleUrls: ['./add-employee.page.scss'],
})
export class AddEmployeePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
