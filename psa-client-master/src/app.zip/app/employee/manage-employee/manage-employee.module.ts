import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ManageEmployeePage } from './manage-employee.page';

import { EditEmployeeComponent } from './../../components/employee/edit-employee/edit-employee.component';
import { AddEmployeeComponent } from './../../components/employee/add-employee/add-employee.component';
import { ListEmployeesComponent } from './../../components/employee/list-employees/list-employees.component';
import { ShowEmployeeComponent } from './../../components/employee/show-employee/show-employee.component';

const routes: Routes = [
  { path: '', component: ManageEmployeePage },
  // { path: 'add', loadChildren: '../add-employee/add-employee.module#AddEmployeePageModule' },
  // { path: 'edit', loadChildren: '../edit-employee/edit-employee.module#EditEmployeePageModule' },
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [
    // EditEmployeeComponent,
    // AddEmployeeComponent,
    // ListEmployeesComponent,
    // ShowEmployeeComponent
  ],
  // declarations: [ManageEmployeePage, EditEmployeeComponent, AddEmployeeComponent, ListEmployeesComponent, ShowEmployeeComponent]
  declarations: [ManageEmployeePage]
})
export class ManageEmployeePageModule {}
