import { Component, OnInit } from '@angular/core';
import {Employee} from 'src/app/models/employee';
import {Events} from '@ionic/angular';

@Component({
  selector: 'app-manage-employee-app-view',
  templateUrl: './manage-employee-app-view.page.html',
  styleUrls: ['./manage-employee-app-view.page.scss'],
})
export class ManageEmployeeAppViewPage implements OnInit {

  // saves employee choice
  // private employee: Employee;
  // controls component view - 0=nothing, 1=show, 2=add, 3=edit
  // private componentID: number;

  constructor() {
    // this.employee = null;
    // this.componentID = 0;
  }

  // public getEmployee() {
  //   return this.employee;
  // }

  // public setEmployee(employee) {
  //   this.employee = employee;
  // }

  // public getComponentID() {
  //   return this.componentID;
  // }

  // public setComponentID(id) {
  //   this.componentID = id;
  // }

  ngOnInit() {
  }

}
