import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-employee-page',
  templateUrl: './show-employee.page.html',
  styleUrls: ['./show-employee.page.scss'],
})
export class ShowEmployeePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
