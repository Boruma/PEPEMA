import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { RouterOutlet, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  pages: any;
  selected: any;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
    this.createNavEntries();
  }

  select(item) {
    this.selected = item;
  };
  isActive(item) {
    return this.selected === item;
  };

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  getTitle(outlet: RouterOutlet) {
    return outlet && outlet.activatedRouteData && outlet.activatedRouteData['title'];
  }

  getShowHeader(outlet: RouterOutlet) {
    return !(outlet.activatedRouteData['showHeader'] == "false");
  }

  showMenu(outlet: RouterOutlet) {
    var isLogin = outlet && outlet.activatedRouteData && outlet.activatedRouteData['title'] == "Login";
    var isSignup = outlet && outlet.activatedRouteData && outlet.activatedRouteData['title'] == 'Neues Unternehmen anlegen'
    return !isLogin && !isSignup;
  }

  createNavEntries() {
    this.pages =
      [
        {
          title: 'Personen',
          url: '/users/employees',
          icon: '../../../assets/icon/persons.svg'
        },
        {
          title: 'Lager',
          url: '/users/ppe',
          icon: '../../../assets/icon/store.svg'
        },
        {
          title: 'Bestellungen',
          url: '/users/orders',
          icon: '../../../assets/icon/order.svg'
        },

        {
          title: 'PSA Schablonen',
          url: '/users/pe',
          icon: '../../../assets/icon/template.svg'
        },
       
        // {
        //   title: 'Einstellungen',
        //   url: '/',
        //   icon: '../../../assets/icon/settings.svg'
        // },
        {
          title: 'Rollen',
          url: '/users/roles',
          icon: '../../../assets/icon/roles.svg'
        },
        {
          title: 'Lieferanten',
          url: '/users/supplier',
          icon: '../../../assets/icon/supplier.svg'
        },
        {
          title: 'Template',
          url: '/design-template',
          icon: '../../../assets/icon/address.svg'
        },
        {
          title: 'Logout',
          url: '/users/logout',
          icon: '../../../assets/icon/logOut.svg'
        }

      ];
  }
}
