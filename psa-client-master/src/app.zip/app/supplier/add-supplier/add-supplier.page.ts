import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-supplier-page',
  templateUrl: './add-supplier.page.html',
  styleUrls: ['./add-supplier.page.scss'],
})
export class AddSupplierPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
