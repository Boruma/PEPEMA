import {Component, OnInit} from '@angular/core';
import {Supplier} from '../../models/Supplier';
import {Events} from '@ionic/angular';

@Component({
  selector: 'app-manage-supplier',
  templateUrl: './manage-supplier.page.html',
  styleUrls: ['./manage-supplier.page.scss'],
})
export class ManageSupplierPage implements OnInit {

  // saves supplier choice
  private supplier: Supplier;

  // controls component view - 0=nothing, 1=show, 2=add, 3=edit
  private componentID: number;

  constructor(private events: Events) {
      this.supplier = null;
      this.componentID = 0;
  }

  public getSupplier() {
      return this.supplier;
  }

  public setSupplier(supplier) {
     
      this.supplier = supplier;
  }

  public getComponentID() {
      return this.componentID;
  }

  public setComponentID(id) {
      this.componentID = id;
  }

  ngOnInit() {
  }

}
