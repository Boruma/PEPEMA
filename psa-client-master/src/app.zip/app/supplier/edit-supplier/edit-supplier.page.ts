import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-supplier-page',
  templateUrl: './edit-supplier.page.html',
  styleUrls: ['./edit-supplier.page.scss'],
})
export class EditSupplierPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
