import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-supplier-page',
  templateUrl: './show-supplier.page.html',
  styleUrls: ['./show-supplier.page.scss'],
})
export class ShowSupplierPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
