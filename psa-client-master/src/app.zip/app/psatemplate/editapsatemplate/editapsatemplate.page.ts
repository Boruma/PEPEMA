import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, FormArray, Validators } from '@angular/forms';
import { PsatemplateService } from "../../services/psatemplate.service";
import { LoadingController } from "@ionic/angular";
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { Pe } from '../../models/pe';



@Component({
  selector: 'app-editapsatemplate',
  templateUrl: './editapsatemplate.page.html',
  styleUrls: ['./editapsatemplate.page.scss'],
})
export class EditapsatemplatePage implements OnInit {

  private Pe = <Pe>{};

  public psaForm: FormGroup;
  public psaFormProperties: FormArray;
  public sizeRangeForm: FormGroup;

  profileForm = new FormGroup({
    psaName: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(20),
    ])
  });

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private fb2: FormBuilder,
    private psatemplateService: PsatemplateService,
    private loadingController: LoadingController,
    private errorService: ErrorhandlingService,
  ) {
    //Get Parameters of Routing
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.Pe = this.router.getCurrentNavigation().extras.state.template;
      }
    });
    this.psaForm = this.fb.group({
      psaFormElements: this.fb.array([]),
    });
    this.sizeRangeForm = this.fb2.group({
      sizeRanges: this.fb2.array([])
    });

  }

  get psaFormControls() {
    return this.psaForm.get('psaFormElements')['controls'];
  }

  //Adds Property to FromBuilder Array
  addProperty(): void {
    this.psaFormProperties = this.psaForm.get('psaFormElements') as FormArray;
    if (this.Pe.properties[0] != null) {
      for (let prop of this.Pe.properties) {
        this.psaFormProperties.push(this.createProperty(prop));
      }
    } else {
      this.Pe.properties = [];
      this.psaFormProperties = null;
    }

    /*
    // this.Pe.properties = this.psaFormProperties.value;
    for (let sizeRange of this.Pe.size_ranges) {
      this.addsizeRange();
    }*/

  }
  addemptyProperty(): void {
    this.psaFormProperties = this.psaForm.get('psaFormElements') as FormArray;
    this.psaFormProperties.push(this.createnewEmptyProperty());
    this.Pe.properties = this.psaFormProperties.value;
  }
  //Removes Property to FromBuilder Array
  removeProperty(i: number) {
    this.psaFormProperties.removeAt(i);
    this.Pe.properties = this.psaFormProperties.value;
  }



  //From for Property
  createProperty(prop): FormGroup {
    if (prop.text != null) {
      return this.fb.group({
        name: { value: prop.name, disabled: false },
        text: { value: prop.text, disabled: false },
        minValue: { value: prop.minValue, disabled: true },
        maxValue: { value: prop.maxValue, disabled: true },
        date: { value: prop.date, disabled: true },
        intervall: { value: prop.intervall, disabled: true },
        type: { value: prop.type, disabled: false },
      });
    }
    if (prop.minValue != null && prop.maxValue == null) {
      return this.fb.group({
        name: { value: prop.name, disabled: false },
        text: { value: prop.text, disabled: true },
        minValue: { value: prop.minValue, disabled: false },
        maxValue: { value: prop.maxValue, disabled: true },
        date: { value: prop.date, disabled: true },
        intervall: { value: prop.intervall, disabled: true },
        type: { value: prop.type, disabled: false },
      });
    }

    if (prop.minValue != null && prop.maxValue != null) {
      return this.fb.group({
        name: { value: prop.name, disabled: false },
        text: { value: prop.text, disabled: true },
        minValue: { value: prop.minValue, disabled: false },
        maxValue: { value: prop.maxValue, disabled: false },
        date: { value: prop.date, disabled: true },
        intervall: { value: prop.intervall, disabled: true },
        type: { value: prop.type, disabled: false },
      });
    }

    if (prop.date != null) {
      return this.fb.group({
        name: { value: prop.name, disabled: false },
        text: { value: prop.text, disabled: true },
        minValue: { value: prop.minValue, disabled: true },
        maxValue: { value: prop.maxValue, disabled: true },
        date: { value: prop.date, disabled: false },
        intervall: { value: prop.intervall, disabled: true },
        type: { value: prop.type, disabled: false },
      });
    }

    if (prop.intervall != null) {
      return this.fb.group({
        name: { value: prop.name, disabled: false },
        text: { value: prop.text, disabled: true },
        minValue: { value: prop.minValue, disabled: true },
        maxValue: { value: prop.maxValue, disabled: true },
        date: { value: prop.date, disabled: true },
        intervall: { value: prop.intervall, disabled: false },
        type: { value: prop.type, disabled: true },
      });
    }



  }

  createnewEmptyProperty(): FormGroup {
    return this.fb.group({
      name: { value: '', disabled: false },
      text: { value: '', disabled: true },
      minValue: { value: '', disabled: true },
      maxValue: { value: '', disabled: true },
      date: { value: '', disabled: true },
      intervall: { value: '', disabled: true },
      type: { value: '', disabled: true },
    });
  }

  public showFormArray($event) {
    let value = $event.detail.value.split(" ");
    console.log(value[0]);
    console.log(value[1]);

    switch (value[0]) {
      case 'intervall': this.showIntervallFormArray(value[1]); break;
      case 'date': this.showDateFormArray(value[1]); break;
      case 'counterAsc': this.showCounterAscFormArray(value[1]); break;
      case 'counterDesc': this.showCounterDescFormArray(value[1]); break;
      case 'value': this.showValueFormArray(value[1]); break;
      case 'text': this.showTextFormArray(value[1]); break;
    }

  }

  editpsatemplate() {
    this.psaForm.markAllAsTouched();
    this.profileForm.markAllAsTouched();
    if (this.psaForm.valid && this.profileForm.valid) {

      this.Pe.name = this.profileForm.value.psaName;
      if (this.Pe.properties[0] != null) {
        this.Pe.properties = this.psaFormProperties.value;
      } else {
        this.Pe.properties = [];
      }

      let loading: HTMLIonLoadingElement;
      this.loadingController.create({
        spinner: "circles"
      }).then(res => {
        loading = res;
        loading.present();
        //console.log(this.Pe);
        this.psatemplateService.editPsaTemplate(this.Pe).then(Pe => {
          console.log("return");
          console.log(Pe);
          this.Pe = Pe;
          loading.dismiss();
        })
          .catch(error => {
            //Errorhandling
            this.errorService.error(error);
            loading.dismiss();
          });
        loading.dismiss();
      });
    }
  }

  showIntervallFormArray(i) {
    this.psaFormProperties.controls[i]['controls'].name.enable();
    this.psaFormProperties.controls[i]['controls'].intervall.enable();
    this.psaFormProperties.controls[i]['controls'].date.disable();
    this.psaFormProperties.controls[i]['controls'].maxValue.disable();
    this.psaFormProperties.controls[i]['controls'].minValue.disable();
    this.psaFormProperties.controls[i]['controls'].text.disable();
    this.psaFormProperties.controls[i]['controls'].type.enable();
    this.psaFormProperties.controls[i]['controls'].type.value = "intervall";

  }

  showDateFormArray(i) {
    this.psaFormProperties.controls[i]['controls'].name.enable();
    this.psaFormProperties.controls[i]['controls'].intervall.disable();
    this.psaFormProperties.controls[i]['controls'].date.enable();
    this.psaFormProperties.controls[i]['controls'].maxValue.disable();
    this.psaFormProperties.controls[i]['controls'].minValue.disable();
    this.psaFormProperties.controls[i]['controls'].text.disable();
    this.psaFormProperties.controls[i]['controls'].type.enable();
    this.psaFormProperties.controls[i]['controls'].type.value = "date";
  }
  showCounterDescFormArray(i) {
    this.psaFormProperties.controls[i]['controls'].name.enable();
    this.psaFormProperties.controls[i]['controls'].intervall.disable();
    this.psaFormProperties.controls[i]['controls'].date.disable();
    this.psaFormProperties.controls[i]['controls'].maxValue.enable();
    this.psaFormProperties.controls[i]['controls'].minValue.enable();
    this.psaFormProperties.controls[i]['controls'].text.disable();
    this.psaFormProperties.controls[i]['controls'].type.enable();
    this.psaFormProperties.controls[i]['controls'].type.value = "downValueRange";

  }

  showCounterAscFormArray(i) {
    this.psaFormProperties.controls[i]['controls'].name.enable();
    this.psaFormProperties.controls[i]['controls'].intervall.disable();
    this.psaFormProperties.controls[i]['controls'].date.disable();
    this.psaFormProperties.controls[i]['controls'].maxValue.enable();
    this.psaFormProperties.controls[i]['controls'].minValue.enable();
    this.psaFormProperties.controls[i]['controls'].text.disable();
    this.psaFormProperties.controls[i]['controls'].type.enable();
    this.psaFormProperties.controls[i]['controls'].type.value = "upValueRange";

  }

  showValueFormArray(i) {
    this.psaFormProperties.controls[i]['controls'].name.enable();
    this.psaFormProperties.controls[i]['controls'].intervall.disable();
    this.psaFormProperties.controls[i]['controls'].date.disable();
    this.psaFormProperties.controls[i]['controls'].maxValue.disable();
    this.psaFormProperties.controls[i]['controls'].minValue.enable();
    this.psaFormProperties.controls[i]['controls'].text.disable();
    this.psaFormProperties.controls[i]['controls'].type.enable();
    this.psaFormProperties.controls[i]['controls'].type.value = "value";

  }

  showTextFormArray(i) {
    this.psaFormProperties.controls[i]['controls'].name.enable();
    this.psaFormProperties.controls[i]['controls'].intervall.disable();
    this.psaFormProperties.controls[i]['controls'].date.disable();
    this.psaFormProperties.controls[i]['controls'].maxValue.disable();
    this.psaFormProperties.controls[i]['controls'].minValue.disable();
    this.psaFormProperties.controls[i]['controls'].text.enable();
    this.psaFormProperties.controls[i]['controls'].type.enable();
    this.psaFormProperties.controls[i]['controls'].type.value = "text";
  }

  ngOnInit() {
    this.addProperty();
  }


  validation_messages = {
    'name': [
      { type: 'required', message: 'Bitte ein gültigen Namen eintragen.' },
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 20 Zeichen bestehen.' }
    ]
  }

  get sizeRanges(): FormGroup {
    return this.fb2.group({
      sizeRangeName: "",
      sizes: this.fb2.array([this.sizes])
    });
  }

  get sizes(): FormGroup {
    return this.fb2.group({
      name: ""
    });
  }

  addsizeRange() {
    (this.sizeRangeForm.get("sizeRanges") as FormArray).push(this.sizeRanges);
  }

  deletesizeRange(index) {
    (this.sizeRangeForm.get("sizeRanges") as FormArray).removeAt(index);
  }

  addSize(sizeRange) {
    sizeRange.get("sizes").push(this.sizes);
  }

  deleteSize(sizeRange, index) {
    sizeRange.get("sizes").removeAt(index);
  }
}

