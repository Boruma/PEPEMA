import { Component, OnInit } from '@angular/core';
import { PsatemplateService } from "../../services/psatemplate.service";
import { LoadingController, AlertController } from "@ionic/angular";
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { Router, NavigationExtras } from '@angular/router';
import { Pe } from 'src/app/models/pe';

@Component({
  selector: 'app-managepsatemplate',
  templateUrl: './managepsatemplate.page.html',
  styleUrls: ['./managepsatemplate.page.scss'],
})
export class ManagepsatemplatePage implements OnInit {

  
  constructor(

  ) {
    
  }

  ngOnInit() {
    
  }
  

}
