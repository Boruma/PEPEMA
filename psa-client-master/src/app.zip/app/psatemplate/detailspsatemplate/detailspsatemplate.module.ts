import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { DetailspsatemplatePage } from './detailspsatemplate.page';
import { ShowPsatemplateComponent } from '../../components/psatemplate/show-psatemplate/show-psatemplate.component';
//import { PsatemplateModule } from '../../components/psatemplate/psatemplate/psatemplate.module';
const routes: Routes = [
  {
    path: '',
    component: DetailspsatemplatePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
  ],
  exports: [
    DetailspsatemplatePage
  ],
  declarations: [DetailspsatemplatePage]
})
export class DetailspsatemplatePageModule { }
