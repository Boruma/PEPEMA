import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-role-page',
  templateUrl: './show-role.page.html',
  styleUrls: ['./show-role.page.scss'],
})
export class ShowRolePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
