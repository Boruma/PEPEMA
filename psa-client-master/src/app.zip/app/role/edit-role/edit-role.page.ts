import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-role-page',
  templateUrl: './edit-role.page.html',
  styleUrls: ['./edit-role.page.scss'],
})
export class EditRolePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
