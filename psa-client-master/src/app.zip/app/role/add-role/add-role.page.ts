import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-role-page',
  templateUrl: './add-role.page.html',
  styleUrls: ['./add-role.page.scss'],
})
export class AddRolePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
