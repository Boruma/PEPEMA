import {Component, OnInit} from '@angular/core';
import {Employee} from '../../models/employee';
import {Role} from '../../models/role';
import {Events} from '@ionic/angular';

@Component({
    selector: 'app-manage-role',
    templateUrl: './manage-role.page.html',
    styleUrls: ['./manage-role.page.scss'],
})
export class ManageRolePage implements OnInit {

    // saves role choice
    private role: Role;

    // controls component view - 0=nothing, 1=show, 2=add, 3=edit
    private componentID: number;

    constructor(private events: Events) {
        this.role = null;
        this.componentID = 0;
    }

    public getRole() {
        return this.role;
    }

    public setRole(role) {
        // console.log(role);
        this.role = role;
    }

    public getComponentID() {
        return this.componentID;
    }

    public setComponentID(id) {
        this.componentID = id;
    }

    ngOnInit() {
    }

}
