import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { Pe } from '../../../models/pe';
import { Events, LoadingController, AlertController } from "@ionic/angular";
import { PsatemplateService } from "../../../services/psatemplate.service";
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';

@Component({
  selector: 'app-show-psatemplate',
  templateUrl: './show-psatemplate.component.html',
  styleUrls: ['./show-psatemplate.component.scss'],
})
export class ShowPsatemplateComponent implements OnInit {

  data: any;
  public Pe = Pe;
  constructor(private route: ActivatedRoute, private router: Router, private events: Events,  
    private alertCtrl: AlertController,
    private loadingController: LoadingController,
     private psatemplateService: PsatemplateService,
      private errorService: ErrorhandlingService,) {
    //Get Parameters of Routing
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.Pe = this.router.getCurrentNavigation().extras.state.template;

      }
    });

    this.events.subscribe('showPsa', (template) => {
      // console.log("show subscribe Employee");
      // console.log(newEmployee);
      this.Pe = template;
    });

  }


  ngOnInit() {
    console.log(this.Pe);

  }

  openUpdateWithState(template) {
    let navigationExtras: NavigationExtras = {
      state: {
        template: template
      }
    };
    this.router.navigate(['users/pe/edit'], navigationExtras);
  }

  async presentAlertConfirm(template) {
    const alert = await this.alertCtrl.create({
      header: 'Schanlone löschen',
      message: '<strong>' + template.name + '</strong> wirklich löschen?',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {

          }
        }, {
          text: 'Okay',
          handler: () => {
            this.deltePsaTemplate(template.pe_ID);
          }
        }
      ]
    });
    await alert.present();
    let result = await alert.onDidDismiss();
  }

  deltePsaTemplate(template) {
    
 
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.psatemplateService.deltePsaTemplate(template).then(res => {
        this.router.navigate(['users/pe']);
      })
        .catch(error => {
          //Errorhandling
          this.errorService.error(error);
          loading.dismiss();
        });
      loading.dismiss();
    });

  }

}
