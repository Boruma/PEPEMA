import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {Role} from '../../../models/role';
import {Events, LoadingController} from '@ionic/angular';
import {ErrorhandlingService} from '../../../services/errorhandling.service';
import {FormBuilder} from '@angular/forms';
import {RoleService} from '../../../services/role.service';
import {ManageRolePage} from '../../../role/manage-role/manage-role.page';
import { Router, NavigationExtras } from '@angular/router';

@Component({
    selector: 'app-list-roles',
    templateUrl: './list-roles.component.html',
    styleUrls: ['./list-roles.component.scss'],
})
export class ListRolesComponent implements OnInit {

    // list of all roles
    private roles: Role[];

    // index of current role
    public listIndex: number;

    constructor(public formBuilder: FormBuilder,
                private roleService: RoleService,
                private errorService: ErrorhandlingService,
                private loadingController: LoadingController,
                private manageRole: ManageRolePage,
                private events: Events,
                private changeDetector: ChangeDetectorRef,
                private router: Router) {
        this.events.subscribe('deleteRole', (role) => {
            this.deleteRole(role.role_ID);
            this.listIndex = -1;
            this.changeDetector.detectChanges();
        });

        this.events.subscribe('updateRoles', (role) => {
            this.getAllRoles();
        });

        this.events.subscribe('addRole', (newRole) => {
            // console.log(newRole);
            this.roles.push(newRole);
            this.listIndex = this.roles.indexOf(newRole);
            this.changeDetector.detectChanges();
        });

    }

    ngOnInit() {
        this.getAllRoles();
    }

    // returns array index of role
    private getIndex(role: Role) {
        for (const index in this.roles) {
            if (this.roles[index].role_ID === role.role_ID) {
                return this.roles.indexOf(this.roles[index]);
            }
        }
        return -1;
    }

    // reads in all roles and saves them to array
    async getAllRoles() {
        this.roleService.getRoles().then(result => {
            if (result.length === 0) {
                console.log('No Roles!');
            }

            this.roles = result;

            const tmpRole: Role = this.manageRole.getRole();
            if (tmpRole == null) {
                this.listIndex = -1;
            } else {
                this.listIndex = this.getIndex(tmpRole);
            }

        })
            .catch(error => {
                console.log('Error: getAllRoles - list-roles.component.ts');
                console.log(error);
                this.errorService.error(error);
            });
    }

    // sets the component
    public showRole(role) {
        let navigationExtras: NavigationExtras = {
            state: {
                role: role,
             
            }
        };
        this.router.navigate([this.router.url + '/show'], navigationExtras);
    }

    public showRoleDesktop(role) {
        this.events.publish('showRole', (role));
        this.manageRole.setRole(role);
        this.manageRole.setComponentID(1);
    }

    public addRole() {
        this.router.navigate([this.router.url + '/add']);
        // this.manageRole.setComponentID(2);
    }

    public deleteRole(id) {
        // delete in server
        this.roleService.deleteRole(id);
        // delete in array
        this.roles.splice(this.roles.findIndex(role => role.role_ID === id), 1);
        this.manageRole.setRole(null);
        this.manageRole.setComponentID(0);
    }

    setListIndex(id: number): void {
        this.listIndex = id;
    }

}
