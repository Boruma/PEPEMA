import { Component, OnInit } from '@angular/core';
import { Role } from '../../../models/role';
import { AlertController, Events } from '@ionic/angular';
import { ManageEmployeePage } from '../../../employee/manage-employee/manage-employee.page';
import { Router, NavigationExtras } from '@angular/router';

@Component({
    selector: 'app-show-role',
    templateUrl: './show-role.component.html',
    styleUrls: ['./show-role.component.scss'],
})
export class ShowRoleComponent implements OnInit {

    private role: Role;

    constructor(
        private events: Events,
        private alertCtrl: AlertController,
        private router: Router) {

        
        // sets  initial role choice
      

        // shows different role
        this.events.subscribe('showRole', (newRole) => {
            this.role = newRole;
        });

        if (this.router.getCurrentNavigation().extras.state != null)
            this.role = this.router.getCurrentNavigation().extras.state.role;
    }

    ngOnInit() {
        if (this.router.getCurrentNavigation().extras.state != null)
            this.role = this.router.getCurrentNavigation().extras.state.role;
    }

    public editRole(role) {

        let navigationExtras: NavigationExtras = {
            state: {
                role: role
            }
        };

        this.router.navigate(['users/roles/edit'], navigationExtras);
    }

    async presentAlertConfirm() {
        const alert = await this.alertCtrl.create({
            header: 'Löschen',
            message: '<strong>' + this.role.name + '</strong> wirklich löschen?',
            buttons: [
                {
                    text: 'Abbrechen',
                    role: 'cancel',
                    cssClass: 'secondary',
                    handler: (blah) => {

                    }
                }, {
                    text: 'Okay',
                    handler: () => {
                        this.deleteRole();
                    }
                }
            ]
        });

        await alert.present();
        const result = await alert.onDidDismiss();
    }

    public deleteRole() {
      
        this.events.publish('deleteRole', this.role);
      
    }
}
