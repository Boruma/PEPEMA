import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { ActivatedRoute } from "@angular/router";
import { PsaService } from "../../../services/psa.service";
import { PPE } from 'src/app/models/ppe';
import { Property } from 'src/app/models/property';
import { size } from 'src/app/models/size';
import { size_range } from 'src/app/models/size_range';
import { Events, AlertController, LoadingController } from '@ionic/angular';
import { Router } from "@angular/router";


@Component({
  selector: 'app-edit-psa',
  templateUrl: './edit-psa.component.html',
  styleUrls: ['./edit-psa.component.scss'],
})
export class EditPsaComponent implements OnInit {
  private url: String;
  public psaForm: FormGroup;
  templates: any;
  sizes: size[];
  sn: any;
  ppe: PPE = <PPE>{};
  edit_id: any;
  dropdownDefaults: any[];

  constructor(
    public formBuilder: FormBuilder,
    private psaService: PsaService,
    private errorService: ErrorhandlingService,
    private route: ActivatedRoute,
    public router: Router,
    public alertController: AlertController,
    private loadingController: LoadingController,
    private events: Events,
  ) {

    this.ppe.properties = Array<Property>();
    this.ppe.size_ranges = Array<size_range>();
    this.psaForm = this.formBuilder.group({

      sn: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(2)
      ])),
      pn: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(2)
      ])),
      comment: new FormControl('', Validators.compose([])),
      commissiondate: new FormControl('', Validators.compose([])),
      state: new FormControl('', Validators.compose([])),

      properties: new FormArray([]),
    });
    // this.getTemplates();

    
    this.edit_id = this.route.snapshot.paramMap.get('id');
    console.log(this.edit_id);

    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.psaService.getPsa(this.edit_id)
        .then(data => {
          this.ppe = data;
          console.log(data);
          this.psaService.getPe(this.ppe.pe_ID).then(template => {
            this.ppe.pe = template;
          });

          if (this.ppe.properties != null) {
            this.ppe.properties.forEach(property => {
              this.addProperty(property);
            });
          }
          //this.getSizes(this.ppe.pe.pe_ID);
        }).catch(error => {
          console.log("no no no");
          this.errorService.error(error);
        });
      loading.dismiss();
    });
    if (this.router.getCurrentNavigation().extras.state) {
      this.ppe = this.router.getCurrentNavigation().extras.state.ppe;
    }
  }

  ngOnInit() { }

  get properties(): FormArray {
    return this.psaForm.get('properties') as FormArray;
  }


  createProperty(property: Property): FormControl {
    switch (property.type) {
      case 'upValueRange':
        return new FormControl('', Validators.compose([
          Validators.min(0)
        ]));
        break;
      case 'downValueRange':
        return new FormControl('', Validators.compose([
          Validators.min(0)
        ]));
        break;
      case 'value':
        return new FormControl('', Validators.compose([
          Validators.min(0)
        ]));
        break;
      case 'date':
        return new FormControl('', Validators.compose([]));
        break;
      case 'text':
        return new FormControl('', Validators.compose([
          Validators.minLength(2)
        ]));
        break;
      case 'intervall':
        return new FormControl('', Validators.compose([
          Validators.min(1)
        ]));
        break;
    }

  }

  addProperty(property: Property) {
    if (property != null)
      this.properties.push(this.createProperty(property));
    // this.ppe.properties.push(new Property(property));
  }


  // async getTemplates() {
  //   this.psaService.getTemplates().then(data => {
  //     this.templates = data;
  //   }).catch(error => {
  //     //Errorhandling here
  //     this.errorService.error(error);
  //   });
  // }

  addTemplateToPsa(template) {
    this.ppe.pe = template;
    //this.getSizes(template.template_id);
    //this.getProperties(template.templade_id);
  }


  addSizeToPsa($event) {


    // range.sizes.forEach(sz => {
    //     if (sz.size_ID == size_id) {
    //         size = sz;
    //     }
    // });
    // range.size = size;
    let range_id = $event.srcElement.id;

    let ppe_range: size_range;
    let range: size_range;

    this.ppe.pe.size_ranges.forEach(sr => {

      if (sr.sizer_ID == range_id) {

        range = sr;
      }

    });

    this.ppe.size_ranges.forEach(sr => {

      if (sr.sizer_ID == range_id) {

        ppe_range = sr;
      }

    });

    console.log(ppe_range);

    ppe_range.sizes[0].name = $event.detail.value;

    console.log(this.ppe);
  }

  updatePsa() {

    //Function that is called when the value of the dropDown changes
    /*for (var entry of this.dropdownOptions) {
        if (entry.val == $event.detail.value) {
            console.log("value: " + $event.detail.value + ", id = " + entry.id);
        }
    }*/


    this.ppe.stock_ID = 1;
    this.ppe.order_ID = null;

    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();

      this.psaService.updatePsa(this.ppe).then(res => {
        // this.events.publish('updatePsas');
        this.presentAlertConfirm();
        this.events.publish('updatePsas'); 
        this.router.navigate([ 'users/ppe']);
        console.log(res);
        loading.dismiss();
      })
        .catch(error => {
          //Errorhandling here
          this.errorService.error(error);
          loading.dismiss();
        });

   
    });


  }

  async presentAlertConfirm() {
    console.log("alert");
    const alert = await this.alertController.create({
      header: 'Die Psa wurde bearbeitet!',
      //message: '',
      buttons: [

        {
          text: 'Okay',
          handler: () => {
            this.router.navigate(['/users/ppe']);
          }
        }
      ]
    });

    await alert.present();
  }


  // getProperties(template_id) {
  //   this.psaService.getProperites(template_id).then(data => {
  //     console.log(data);
  //     this.ppe.properties = data;
  //     this.ppe.properties.forEach(property => {
  //       this.addProperty(property);
  //     });
  //     ;
  //   }).catch(error => {
  //     //Errorhandling here
  //     this.errorService.error(error);
  //   });
  // }


}
