
import { Component, OnInit } from '@angular/core';
import { PsaService } from "../../../services/psa.service";
import { PPE } from 'src/app/models/ppe';
import { Events } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { LoadingController } from "@ionic/angular";
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-list-psa',
  templateUrl: './list-psa.component.html',
  styleUrls: ['./list-psa.component.scss'],
})
export class ListPsaComponent implements OnInit {

  ppes: PPE[];
  active_ppe: PPE = <PPE>{};

  constructor(
    private psaService: PsaService,
    public router: Router,
    private events: Events,
    public alertController: AlertController,
    private errorService: ErrorhandlingService,
    private loadingController: LoadingController
  ) {
    this.active_ppe = new PPE();
    this.events.subscribe('deletePsa', (id) => {
      this.deletePsa(id);
    });

    this.events.subscribe('updatePsas', () => {
      this.getPsas();
    });
  }

  ngOnInit() {
    this.getPsas();
  }

  // ionViewDidEnter() {
  //   this.getPsas();
  // }

  async getPsas() {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();

      this.psaService.getPsas(1).then(data => {

        this.ppes = data['ppes'];
        console.log(data);
        loading.dismiss();
      }).catch(error => {
        loading.dismiss();
        this.errorService.error(error);

      });


    });

  }

  public returnPsa(): PPE {
    return this.active_ppe;
  }

  public setActivePsa(psa: PPE) {
    this.active_ppe = psa;
  }

  showPpeDetails(index) {

    //this.events.publish("showPsa", (this.ppes[index])); //um Employee zu aktualisieren (weil show Employee nur einmal manageEmployee.getEmployee macht)
    //this.active_ppe = this.ppes[index];
    let navigationExtras: NavigationExtras = {
      state: {
        ppe: this.ppes[index],
        url: this.router.url
      }
    };

    console.log(this.ppes[index]);
    this.router.navigate([this.router.url + '/show'], navigationExtras);
  }

  showPpeDetailsDesktop(index) {
    this.events.publish('showPpe', (this.ppes[index]));
  }

  updatePsa(ppe) {
    let navigationExtras: NavigationExtras = {
      state: {
        ppe: ppe
      }
    };
    
    this.router.navigate(['/users/ppe/edit', ppe]);
  }

  addPsa() {
    this.router.navigate(['/users/ppe/add']);
  }


  deletePsa(id) {
    let ppe: PPE;

    this.ppes.forEach(p => {
      if (p.sn == id) {
        ppe = p;
      }
    });
    if (ppe.state == "Ausgemustert") {
      this.presentAlertConfirmDelete(ppe, id);
    }
    else {
      ppe.state = "Ausgemustert";

      this.psaService.updatePsa(ppe).then(res => {
        console.log(res);
      });
    }
  }

  async presentAlertConfirmDelete(ppe, id) {
    console.log("PresentAlart");
    const alert = await this.alertController.create({
      header: 'Die Psa endgültig löschen?',
      //message: '',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {

          }
        },
        {
          text: 'Okay',
          handler: () => {
            let loading: HTMLIonLoadingElement;
            this.loadingController.create({
              spinner: "circles"
            }).then(res => {
              loading = res;
              loading.present();

              this.psaService.deletePsa(id)
                .then(data => {
                  this.events.publish("showPsa");

                  this.ppes.splice(this.ppes.indexOf(ppe), 1);
                  if (this.ppes.length > 0) {
                    this.active_ppe = this.ppes[0];

                  }
                  this.router.navigate(['/users/ppe']);

                }).catch(error => {

                  this.errorService.error(error);
                });

              loading.dismiss();
            });

          }
        }
      ]
    });

    await alert.present();
  }



}
