import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { PsaService } from "../../../services/psa.service";
import { SupplierService } from "../../../services/supplier.service";
import { OrderService } from "../../../services/order.service";
import { PPE } from 'src/app/models/ppe';
import { Property } from 'src/app/models/property';
import { size } from 'src/app/models/size';
import { size_range } from 'src/app/models/size_range';
import { AlertController } from '@ionic/angular';
import { Router, NavigationExtras } from "@angular/router";
import { LoadingController } from "@ionic/angular";
import { Events } from '@ionic/angular';
import { Supplier } from 'src/app/models/Supplier';
import { Pe } from 'src/app/models/pe';
import { Role } from 'src/app/models/Role';
import { Observable, of, throwError } from 'rxjs';
import { AddOrderComponent } from '../../order/add-order/add-order.component';
import { Order } from 'src/app/models/order';

@Component({
  selector: 'app-create-psa',
  templateUrl: './create-psa.component.html',
  styleUrls: ['./create-psa.component.scss'],
})
export class CreatePsaComponent implements OnInit {


  //übergebene Daten
  private incomingUrl: string;
  private stockOrOrder: number = -1; //0=Stock,  1=Order 
  private supplier: Supplier = <Supplier>{}; //for finding possible pe
  private addOrderComponent: AddOrderComponent;

  private stock: boolean = true;

  private pes: Pe[] = new Array<Pe>(); //selection of alle possible items
  private pesIsEmpty: boolean = true;

  public psaForm: FormGroup;
  private size: size;
  private sn: any;
  private ppe: PPE = new PPE();
  private peIsChoosed = false;

  //private tmpPpes: PPE[] = new Array<PPE>();

  ///////////////todo: entfernen, nur zum testen
  s1: size = <size>{};
  s2: size = <size>{};
  sizerange: size_range = <size_range>{};
  r: Role = <Role>{};
  pe: Pe = <Pe>{};
  //////////

  constructor(

    public formBuilder: FormBuilder,
    private psaService: PsaService,
    private supplierService: SupplierService,
    private orderService: OrderService,
    private errorService: ErrorhandlingService,
    public alertController: AlertController,
    public router: Router,
    private events: Events,
    private loadingController: LoadingController,
  ) {

    ///////////////todo: entfernen, nur zum testen
    this.sizerange.sizer_ID = 100;
    this.s1.size_ID = 10;
    this.s2.size_ID = 11;
    this.s1.name = "S";
    this.s2.name = "M";
    this.s1.sizer_ID = 100;
    this.s2.sizer_ID = 100;
    this.sizerange.name = "S-M";
    this.sizerange.sizes = new Array();
    this.sizerange.sizes.push(this.s1);
    this.sizerange.sizes.push(this.s2);
    this.r.name = "Arschkriecher"
    this.r.role_ID = 12;
    this.pe.pe_ID = 15;
    this.pe.name = "Schutz vor Schlag in den Nacken";
    this.pe.size_ranges = new Array();
    this.pe.size_ranges.push(this.sizerange);
    this.pe.roles = new Array();
    this.pe.roles.push(this.r);
    this.pe.supplItemID = "1234567";
    ///////////////

    this.getRoutingData();
    if (this.supplier.supplier_ID != null) {
      this.getPesForSupplier();
    }
    this.preparePpe();

    this.ppe.properties = Array<Property>();
    this.ppe.size_ranges = Array<size_range>();
    this.psaForm = this.formBuilder.group({

      // sn: new FormControl('', Validators.compose([
      //   Validators.required,
      //   Validators.minLength(2)
      // ])),
      // pn: new FormControl('', Validators.compose([
      //   Validators.required,
      //   Validators.minLength(2)
      // ])),
      comment: new FormControl('', Validators.compose([
        Validators.maxLength(150),
      ])),
      // commissioningdate: new FormControl('', Validators.compose([

      // ])),
      // state: new FormControl('', Validators.compose([
      //   Validators.maxLength(30),
      // ])),

      properties: new FormArray([]),
    });

  }

  ngOnInit() {
  }

  //Caller has to transfer infos
  private getRoutingData() {
    this.stockOrOrder = this.router.getCurrentNavigation().extras.state.stockType;
    this.supplier = this.router.getCurrentNavigation().extras.state.supplier;
    //order_ID = null if add-order is calling; order_ID = 139 (e.g.) if show-order is calling
    this.ppe.order_ID = this.router.getCurrentNavigation().extras.state.order_ID;
    this.incomingUrl = this.router.getCurrentNavigation().extras.state.url;
  }

  private preparePpe() {
    console.log("preparePPE");
    // this.ppe = new PPE();
    // this.ppe.properties = new Array<Property>();
    // this.ppe.size_ranges = new Array<size_range>();
    // this.ppe.pe = <Pe>{};
    // this.ppe.pe.properties = new Array<Property>();
    // this.ppe.pe.size_ranges = new Array<size_range>();
    // this.ppe.pe.roles = new Array<Role>();




    // this.ppe.created_at = null;
    // this.ppe.updated_at = null;

    // this.ppe.sn = "";
    // this.ppe.commissioningdate=  null;
    // this.ppe.comment = null;
    // this.ppe.state = null;
    // this.delivered = null;
    // this.size_ranges = null;
    // this.properties = null;
    // this.template = null;

    //PPE zum Lager hinzufuegen. todo: unterschiedliche lager oder lager im Backend zuweisen?
    if (this.stockOrOrder == 0) {
      this.ppe.stock_ID = 1 //todo - nicht hart reincoden, aus backend abfragen?
      this.stock = true;
      // console.log("Psa für Lager ID: " + this.ppe.stock_ID);
    }
    //PPE zu Order hinzufuegen 
    else if (this.stockOrOrder == 1) {
      // console.log("Psa für Order")
      this.ppe.stock_ID = null;
      this.stock = false;
    }
  }

  //selection of PSA for the User - in createPsa
  private getPesForSupplier() {

    //todo - alle pe zu einem Supplier holen und setzen + ggf. pesIsEmpty = true
    // this.pes.push(this.pe);
    // this.pesIsEmpty = false;
    // console.log(this.pes);

    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.supplierService.getAllPEBySupplier(this.supplier.supplier_ID).then(resPes => {
        this.pes = resPes;
        if (this.pes.length != 0) {
          this.pesIsEmpty = false;
        }
        loading.dismiss();
      }).catch(error => {
        //Errorhandling here
        this.errorService.error(error);
        loading.dismiss();
      });
    });
  }

  private addTemplateToPpe($event) {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      // console.log("Ausgewälte Pe Id:" + $event.detail.value);
      this.ppe.pe = this.getPeById($event.detail.value);
      if (this.ppe.pe != null) {
        this.ppe.pe_ID = this.ppe.pe.pe_ID;
        // this.ppe.pe.supplItemID = "aaaaaaaaaa";
        //add Properties
        if (this.ppe.pe.properties != null) {
          this.ppe.pe.properties.forEach(property => {
            // console.log("add Property..");
            this.addProperty(property);
          });
        }
        //add Sizes
        if (this.ppe.pe.size_ranges != null) {
          // console.log(this.ppe.pe.size_ranges);
          this.ppe.pe.size_ranges.forEach(sr => {
            this.ppe.size_ranges.push(new size_range(sr.sizes[0], sr));
            // console.log("add Sizerange..");
          });
          // console.log(this.ppe.size_ranges);
        }
      }
      this.peIsChoosed = true;
      loading.dismiss();
    });
  }

  private getPeById(id): Pe {
    for (var pe of this.pes) {
      if (pe.pe_ID == id) {
        return pe;
      }
    }
    return null;
  }


  get properties(): FormArray {
    return this.psaForm.get('properties') as FormArray;
  }


  createProperty(property: Property): FormControl {
    switch (property.type) {
      case 'upValueRange':
        return new FormControl('', Validators.compose([
          Validators.min(0)
        ]));
        break;
      case 'downValueRange':
        return new FormControl('', Validators.compose([
          Validators.min(0)
        ]));
        break;
      case 'value':
        return new FormControl('', Validators.compose([
          Validators.min(0)
        ]));
        break;
      case 'date':
        return new FormControl('', Validators.compose([

        ]));
        break;
      case 'text':
        return new FormControl('', Validators.compose([
          Validators.minLength(2)
        ]));
        break;
      case 'intervall':
        return new FormControl('', Validators.compose([
          Validators.min(1)
        ]));
        break;
    }
  }

  addProperty(property: Property) {
    if (property != null) {
      this.properties.push(this.createProperty(property));
    }
    if (property != null) {
      this.ppe.properties.push(new Property(property));
    }
  }



  addSizeToPsa($event) {
    // console.log("addSizeToPsa");
    let range_id = $event.srcElement.id;
    let ppe_range: size_range;
    let range: size_range;
    this.ppe.pe.size_ranges.forEach(sr => {
      if (sr.sizer_ID == range_id) {
        range = sr;
      }
    });
    this.ppe.size_ranges.forEach(sr => {
      if (sr.sizer_ID == range_id) {
        ppe_range = sr;
      }
    });
    for (var s of range.sizes) {
      if (s.size_ID == $event.detail.value) {
        if (ppe_range != null) {
          ppe_range.sizes[0] = s;
        }
        else {
          this.ppe.size_ranges.push(new size_range(s, range));
        }
      }
    }
  }

  addPsa() {
    if (this.stockOrOrder == 0) {
      // //PPE zum Lager hinzufuegen. todo: unterschiedliche lager oder lager im Backend zuweisen?
      // if (this.stockOrOrder == 0) {
      //   this.ppe.stock_ID = 1 //todo - nicht hart reincoden, aus backend abfragen?
      //   this.stock = true;
      //   console.log("Psa für Lager ID: " + this.ppe.stock_ID);

      // let loading: HTMLIonLoadingElement;
      // this.loadingController.create({
      //   spinner: "circles"
      // }).then(res => {
      //   loading = res;
      //   loading.present();
      //   this.psaService.createPsa(this.ppe).then(res => {
      //     this.presentAlertConfirm();
      //     this.events.publish('updatePsas'); //reset psa-List in list-employee
      //   })
      //     .catch(error => {
      //       //Errorhandling here
      //       this.errorService.error(error);
      //     });
      //   loading.dismiss();
      // });
    }
    //PPE zu tmpOrder hinzufuegen 
    if (this.stockOrOrder == 1) {
      console.log(this.ppe);
      this.orderService.addNewPpe(this.ppe);

      //creates ppe in db and go back to caller page with the Order
      if (this.ppe.order_ID != null) {
        this.getOrderGoBack(this.ppe.order_ID);
      }
      //go back to caller page without params
      else {
        this.router.navigate([this.incomingUrl]); //back to caller Page
      }


    } else {
      // todo? Fehler?
    }
  }

  //creates ppe in db and go back to caller page with the Order
  async getOrderGoBack(id) {
    const loading = await this.loadingController.create({
      message: 'Loading'
    });
    await loading.present();
    //create ppe
    this.psaService.createPsa(this.ppe).then(() => {
      //go back with order
      this.orderService.getOrder(id).then(order => {
        let navigationExtras: NavigationExtras = {
          state: {
            order: order,
            url: this.router.url,
          }
        };
        console.log(navigationExtras);
        this.router.navigate([this.incomingUrl], navigationExtras);
        loading.dismiss();

      }, err => {
        console.log(err);
        loading.dismiss();
      });

    }, err => {
      console.log(err);
      loading.dismiss();
    });
  }


  // async presentAlertConfirm() {

  //   const alert = await this.alertController.create({
  //     header: 'Die Psa wurde angelegt!',
  //     //message: '',
  //     buttons: [

  //       {
  //         text: 'Okay',
  //         handler: () => {
  //           this.router.navigate(['/users/ppe']);
  //         }
  //       }
  //     ]
  //   });

  //   await alert.present();
  // }

  validation_messages = {
    'sn': [
      { type: 'required', message: 'Bitte eine gültige SN eintragen.' },
      { type: 'minlength', message: 'Die SN muss mindesten aus 2 Zeichen bestehen.' }
    ],
    'pn': [
      { type: 'required', message: 'Bitte eine gültige PN eintragen.' },
      { type: 'minlength', message: 'Die PN muss mindesten aus 2 Zeichen bestehen.' },
    ],
    'comment': [
      { type: 'maxlength', message: 'Der Kommentar darf maximal aus 150 Zeichen bestehen.' }
    ],
    'commissioningdate': [
    ],
    'state': [
      { type: 'maxlength', message: 'Der Status darf maximal aus 30 Zeichen bestehen.' }
    ],

  }

}
