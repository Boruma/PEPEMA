import { Component, OnInit } from '@angular/core';
import { PPE } from 'src/app/models/ppe';
import { ModalController } from '@ionic/angular';

import { Events } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { LoadingController } from "@ionic/angular";
import { PsaService } from "../../../services/psa.service";
import { AlertController } from '@ionic/angular';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';

@Component({
  selector: 'app-show-psa',
  templateUrl: './show-psa.component.html',
  styleUrls: ['./show-psa.component.scss'],
})
export class ShowPsaComponent implements OnInit {

  private url: String;
  private ppe: PPE;

  constructor(
    public modalController: ModalController,
    private events: Events,
    private router: Router,
    private loadingController: LoadingController,
    private psaService: PsaService,
    public alertController: AlertController,
    private errorService: ErrorhandlingService,
    
  ) {
    // events.subscribe("showPsa", (newPsa) => {
    //   this.ppe = newPsa;
    // });
    // events.subscribe("deletePSA", () => {
    //   this.ppe.sn = "";
    // });

    if (this.router.getCurrentNavigation().extras.state != null)
      this.ppe = this.router.getCurrentNavigation().extras.state.ppe;


    this.events.subscribe('showPpe', (newPpe) => {
      this.ppe = newPpe;
    });

    console.log(this.ppe);
    //this.url = this.router.getCurrentNavigation().extras.state.url;
    // this.managePsa.setActivePsa(this.ppe);
  }

  ngOnInit() { }

  deletePsa(ppe) {

      this.presentAlertConfirmDelete(ppe);
   
  }

  async presentAlertConfirmDelete(ppe) {
    console.log("PresentAlart");
    const alert = await this.alertController.create({
      header: 'Die Psa endgültig löschen?',
      //message: '',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {

          }
        },
        {
          text: 'Okay',
          handler: () => {
            let loading: HTMLIonLoadingElement;
            this.loadingController.create({
              spinner: "circles"
            }).then(res => {
              loading = res;
              loading.present();

              this.psaService.deletePsa(ppe.sn)
                .then(data => {
                  this.events.publish("showPsa");

                  
                  this.router.navigate(['/users/ppe']);

                }).catch(error => {

                  this.errorService.error(error);
                });

              loading.dismiss();
            });

          }
        }
      ]
    });

    await alert.present();
  }

  
  updatePsa(ppe) {
    let navigationExtras: NavigationExtras = {
      state: {
        ppe: ppe
      }
    };
    this.router.navigate(['users/ppe/edit'], navigationExtras);
  }

}
