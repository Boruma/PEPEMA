/*
* Komponente alt. Ersetzt durch psa/showPsa
*/

import { Component, OnInit } from '@angular/core';
import { ManagePsaPage } from "../../psa/manage-psa/manage-psa.page";
import { PPE } from 'src/app/models/ppe';
import { Events } from '@ionic/angular';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-show-ppe',
  templateUrl: './show-ppe.component.html',
  styleUrls: ['./show-ppe.component.scss'],
})
export class ShowPpeComponent implements OnInit {

  private ppe: PPE;

  constructor(private managePsa: ManagePsaPage,
    private events: Events,
    public modalController: ModalController) {

    // events.subscribe("showPsa", (newPsa) => {
    //   this.ppe = newPsa;

      
    // });

    // events.subscribe("deletePSA", () => {
    //   this.ppe.sn = "";
    // });

    // this.ppe = this.managePsa.returnPsa();
    
    // this.managePsa.setActivePsa(this.ppe);
  }



  ngOnInit() {
    
   }

  //  deletePsa(id){
  //   this.managePsa.deletePsa(id);
  //  }


  //  updatePsa(id){
  //   this.managePsa.updatePsa(id);
  //  }
}
