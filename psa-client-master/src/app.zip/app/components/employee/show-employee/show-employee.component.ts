

import { Component, OnInit } from '@angular/core';
//import { ManageEmployeePage } from '../../../employee/manage-employee/manage-employee.page';
//import { ManageEmployeeAppViewPage } from '../../../employee/manage-employee-app-view/manage-employee-app-view.page';

import { Employee } from 'src/app/models/employee';
import { Events, AlertController } from '@ionic/angular';
import { Role } from '../../../models/role';
import { EmployeeService } from '../../../services/employee.service';
import { ErrorhandlingService } from '../../../services/errorhandling.service';

import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';


@Component({
    selector: 'app-show-employee',
    templateUrl: './show-employee.component.html',
    styleUrls: ['./show-employee.component.scss'],
})
export class ShowEmployeeComponent implements OnInit {

    private url: String;
    private employee: Employee;
    private roles: Role[];

    constructor(
        //private manageEmployee: ManageEmployeeAppViewPage,
        private events: Events,
        private alertCtrl: AlertController,
        private employeeService: EmployeeService,
        private errorService: ErrorhandlingService,
        private router: Router
    ) {

        // sets  initial employee for Appview - hier oder onInit()?
        if (this.router.getCurrentNavigation().extras.state != null) {
            this.employee = this.router.getCurrentNavigation().extras.state.employee;
            this.url = this.router.getCurrentNavigation().extras.state.url;
        }

        // shows different employee
        // "this.manageEmployee.setEmployee" und "this.manageEmployee.setComponentID(1)" In publisherclass
        this.events.subscribe('showEmployee', (newEmployee) => {
            // console.log("show subscribe Employee");
            // console.log(newEmployee);
            this.employee = newEmployee;
        });

        if (this.employee != null) {
            this.getRolesFromEmployee();
        }

        this.events.subscribe('role', (role) => {
            this.getRolesFromEmployee();
        });

        

        this.events.subscribe('showEmployee', (newEmployee) => {
            this.employee = newEmployee;
          });
    }

    ngOnInit() {
        if (this.router.getCurrentNavigation().extras.state != null) {
            this.employee = this.router.getCurrentNavigation().extras.state.employee;
        }

    }

    ionViewDidEnter() {
        if (this.router.getCurrentNavigation().extras.state != null) {
            this.employee = this.router.getCurrentNavigation().extras.state.employee;
        }
    }

    //only show address if employee got one
    public showAddress() {
        //No address in DB gives us null
        if (this.employee.address == null) {
            return false;
            //Add a new Employee without address input   
        } else if (
            this.employee.address.address_additional == null &&
            this.employee.address.housenumber == null &&
            this.employee.address.place == null &&
            this.employee.address.postcode == null &&
            this.employee.address.street == null) {
            return false;
        }
        return true;
    }




    async presentAlertConfirm() {
        const alert = await this.alertCtrl.create({
            header: 'Löschen',
            message: '<strong>' + this.employee.name + '</strong> wirklich löschen?',
            buttons: [
                {
                    text: 'Abbrechen',
                    role: 'cancel',
                    cssClass: 'secondary',
                    handler: (blah) => {

                    }
                }, {
                    text: 'Okay',
                    handler: () => {
                        this.deleteEmployee();
                    }
                }
            ]
        });

        await alert.present();
        let result = await alert.onDidDismiss();
    }










    public editEmployee() {
        let navigationExtras: NavigationExtras = {
            state: {
                employee: this.employee
            }
        };
        this.router.navigate(['users/employees/edit'], navigationExtras);
    }

    public deleteEmployee() {
        this.events.publish('deleteEmployee', this.employee);
        this.router.navigate(['users/employees']);
    }

    getRolesFromEmployee() {
        this.employeeService.getAllRolesFromEmployee(this.employee.employee_ID).then(result => {
            //console.log('showEmployee - getRolesFromEmployee');
            //console.log(result);
            if (result == null) {
                this.roles = [];
            } else {
                this.roles = result;
            }
        }).catch(error => {
            console.log('Error: getRoles - show-employee.component.ts');
            console.log(error);
            this.errorService.error(error);
        });
    }



    public showEmployee(employee) {
        let navigationExtras: NavigationExtras = {
            state: {
                employee: employee,
                url: this.router.url
            }
        };
        this.router.navigate(['users/employees/show'], navigationExtras);
        //this.router.navigate([this.router.url + '/show'], navigationExtras);
    }

    public showListEmployee() {
        this.router.navigate(['users/employees']);
    }

    //********************** Methoden für AppAnsicht ****************




    //********************** Methoden für DesktopAnsicht ****************
    //Funktionieren zz. nicht, weil manageEmployeenicht eingebunden werden kann
    // public editEmployee() {
    //     //this.manageEmployee.setComponentID(3);
    // }

    // public deleteEmployee() {
    //     //this.manageEmployee.setComponentID(0);
    //     this.events.publish('deleteEmployee', this.employee);
    //     //this.manageEmployee.setEmployee(null);
    // }
}
