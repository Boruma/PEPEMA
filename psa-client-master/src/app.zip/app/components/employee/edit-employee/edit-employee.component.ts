import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {EmployeeService} from '../../../services/employee.service';
import {ErrorhandlingService} from 'src/app/services/errorhandling.service';
import {Employee} from 'src/app/models/employee';
import {Address} from 'src/app/models/address';
import {LoadingController} from '@ionic/angular';
import {Events, AlertController} from '@ionic/angular';
// import {ManageEmployeePage} from '../../../employee/manage-employee/manage-employee.page';
import {Role} from '../../../models/role';
import {ActivatedRoute, Router, NavigationExtras} from '@angular/router';


@Component({
    selector: 'app-edit-employee',
    templateUrl: './edit-employee.component.html',
    styleUrls: ['./edit-employee.component.scss'],
})

export class EditEmployeeComponent implements OnInit {
    createForm: FormGroup;
    addressForm: FormGroup;

    private employee: Employee = <Employee>{};
    private originEmployee: Employee;
    id: number;
    addressToggle: boolean = false;
    private showAdrDelActivate: boolean = null;
    private showAdressDeleted: boolean = false;

    otherRoles: Role[];

    constructor(public formBuilder: FormBuilder,
                private employeeService: EmployeeService,
                private errorService: ErrorhandlingService,
                private loadingController: LoadingController,
                // private manageEmployee: ManageEmployeePage,
                private events: Events,
                private alertCtrl: AlertController,
                private router: Router) {
        this.prepareEmployee();

        // this.employee.address = <Address>{};
        this.createForm = this.formBuilder.group({
            id: ['',],
            name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
            email: ['', [Validators.email, Validators.minLength(5), Validators.maxLength(40), Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
            phonenumber: ['', [Validators.minLength(5), Validators.maxLength(20)]],
            locker: ['',],
            toggleAddress: ['',]
        });
        this.addressForm = this.formBuilder.group({
            place: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(30)]],
            street: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
            housenumber: ['', [Validators.required, Validators.maxLength(10)]],
            postcode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
            address_additional: ['', [Validators.minLength(2), Validators.maxLength(30)]]
        });
        this.addressForm.disable();
        this.events.subscribe('editEmployee', (employee) => {
            this.employee = employee;
        });

        // ----------------------------------------------------------------------
        // Role

        // roles of origin employee in db updated
        this.events.subscribe('role', (role) => {
            // this.getRolesFromEmployee();
        });

        // added or removed role from employee
        this.events.subscribe('employeeRole', (role) => {
            this.getOtherRoles();
        });

        // todo: ändern wenn backend angepasst
        this.employeeService.getAllRolesFromEmployee(this.employee.employee_ID).then(result => {
            this.employee.roles = result;
            this.getOtherRoles();
        });
    }

    ngOnInit() {
    }

    private prepareEmployee() {
        this.originEmployee = this.router.getCurrentNavigation().extras.state.employee;
        console.log(this.originEmployee);
        this.employee = this.employeeService.copyEmployee(this.originEmployee);
        console.log(this.employee);
        if (this.employee['address'] == null) {
            console.log('keine adresse');
            console.log(this.employee['address']);
            this.employee.address = <Address>{};
        }
        if (this.originEmployee.address) {
            console.log(this.originEmployee)
            console.log('Adresse bereits angelegt');
            console.log(this.originEmployee.address);
            this.addressToggle = true;
            setTimeout(() => this.addressForm.enable(), 0);
        }

    }

    async presentAlertConfirm() {
        const alert = await this.alertCtrl.create({
            header: 'Person ändern',
            message: '<strong>' + this.employee.name + '</strong> wirklich ändern?',
            buttons: [
                {
                    text: 'Abbrechen',
                    role: 'cancel',
                    cssClass: 'secondary',
                    handler: (blah) => {

                    }
                }, {
                    text: 'Okay',
                    handler: () => {
                        this.editEmployee();
                    }
                }
            ]
        });
        await alert.present();
        let result = await alert.onDidDismiss();
    }

    //edits the values of an employee
    editEmployee() {
        if (!this.addressToggle) {
            this.employee.address = <Address>{};
        }
        let loading: HTMLIonLoadingElement;
        this.loadingController.create({
            spinner: 'circles'
        }).then(res => {
            loading = res;
            loading.present();
            this.employeeService.editEmployee(this.employee).then(employee => {
                //console.log(employee);
                //console.log(employee['address']['place'] != null);

                if (employee['address'] != null && employee['address']['place'] != null) {
                    setTimeout(() => this.addressForm.enable(), 0);
                    this.addressToggle = true;
                    this.employee = employee;
                } else {
                    setTimeout(() => this.addressForm.disable(), 0);
                    this.addressToggle = false;
                    this.employee.name = employee['name'];
                    this.employee.email = employee['email'];
                    this.employee.phonenumber = employee['phonenumber'];
                    this.employee.locker = employee['locker'];
                    this.employee.employee_ID = employee['employee_ID'];
                    this.employee.address = <Address>{};
                    console.log(this.employee.address);
                }
                loading.dismiss();

                // todo
                // edit role in db
                this.writeRolesInDB();

                this.originEmployee = this.employee;
                // console.log("neue Daten werden weitergegeben:");
                // console.log(this.originEmployee);
                //this.events.publish('showEmployee', (this.originEmployee));
                // this.manageEmployee.setEmployee(this.originEmployee);
                // this.manageEmployee.setComponentID(1);
                this.events.publish('updateEmployees', this.originEmployee);
                this.events.publish('role', this.originEmployee);
                this.router.navigate(['users/employees']);

            })
                .catch(error => {
                    //Errorhandling
                    this.errorService.error(error);
                    loading.dismiss();
                });
        });


    }


    private showEmployee() {
        this.events.publish('showEmployee', (this.employee));
        // this.manageEmployee.setEmployee(this.employee);
        // this.manageEmployee.setComponentID(1);
    }

    //gets the information for an employee
    getEmployee($id) {
        setTimeout(() => this.addressForm.disable(), 0);
        this.addressToggle = false;
        let loading: HTMLIonLoadingElement;
        this.loadingController.create({
            spinner: 'circles'
        }).then(res => {
            loading = res;
            loading.present();
            this.employeeService.getEmployee($id).then(employee => {
                //console.log(employee);
                //console.log(employee);
                //console.log(employee['address'] != null);
                if (employee['address'] != null && employee['address']['place'] != null) {
                    setTimeout(() => this.addressForm.enable(), 0);
                    this.addressToggle = true;
                    this.employee = employee;
                } else {
                    setTimeout(() => this.addressForm.disable(), 0);
                    this.addressToggle = false;
                    this.employee.name = employee['name'];
                    this.employee.email = employee['email'];
                    this.employee.phonenumber = employee['phonenumber'];
                    this.employee.locker = employee['locker'];
                    this.employee.employee_ID = employee['employee_ID'];
                    this.employee.address = <Address>{};
                }
                loading.dismiss();
            })
                .catch(error => {
                    //Errorhandling
                    this.errorService.error(error);
                    loading.dismiss();
                });
        });
    }

    toggleAddressForm() {
        if (this.addressToggle) {
            if (this.showAdrDelActivate == null) {
                this.showAdrDelActivate = true;
            }
            setTimeout(() => this.addressForm.disable(), 0);
        } else {
            setTimeout(() => this.addressForm.enable(), 0);
        }
    }

    toggleDeleteMessage() {
        if (this.showAdrDelActivate == true) {
            if (this.showAdressDeleted) {
                this.showAdressDeleted = false;
            } else {
                this.showAdressDeleted = true;
            }
        }
    }

    /*
    // sets the role chosen by the dropdown
    pickRole(event) {
        this.addRoleId = event.detail.value;
    }*/

    // todo
    getOtherRoles() {
        this.employeeService.getAllRoles().then(result => {
            // other roles = all roles
            if (result == null || result === undefined) {
                this.otherRoles = [];
            } else {
                this.otherRoles = result;

                // remove the already added roles from other roles
                this.employee.roles.forEach(role => {
                    this.otherRoles.splice(this.otherRoles.findIndex(findRole => findRole.role_ID === role.role_ID), 1);
                });
            }
        }).catch(error => {
            console.log('Error: getOtherRoles - edit-employee.component.ts');
            console.log(error);
            this.errorService.error(error);
        });
    }


// todo
// adds a role to an employee model
    addRole(addRole: Role) {
        if (addRole != null) {
            // add role to the temporary employee
            this.employee.roles.push(addRole);

            this.events.publish('employeeRole', addRole);
        }
    }

// todo
// removes a role from an employee model
    removeRole(removeRole: Role) {
        console.log('removeRole: ' + removeRole.role_ID);
        if (removeRole !== null) {
            // remove role from the temporary employee
            /*
            this.employee.roles.splice(
                this.employee.roles.findIndex(role => role.role_ID === removeRole.role_ID), 1);*/
            const removeIndex = this.employee.roles.indexOf(removeRole);
            if (removeIndex >= 0) {
                this.employee.roles.splice(removeIndex, 1);
            }
            this.events.publish('employeeRole', removeRole);
        }
    }

    writeRolesInDB() {
        let removeRoles: Role[];
        let addRoles: Role[];

        removeRoles = [];
        addRoles = [];

        if (this.employee.roles === undefined) {
            this.employee.roles = [];
        }

        const employeeRoles = this.employee.roles;

        this.employeeService.getAllRolesFromEmployee(this.originEmployee.employee_ID).then(result => {
            if (result !== undefined) {
                this.originEmployee.roles = result;
            } else {
                this.originEmployee.roles = [];
            }

            console.log('New Roles:');
            console.log(employeeRoles);
            console.log('Old Roles:');
            console.log(this.originEmployee.roles);

            // define which roles have to be removed and remove them
            for (let role of this.originEmployee.roles) {
                console.log('origin: ' + role.role_ID);
                let remove = true;
                for (let newRole of employeeRoles) {
                    console.log('employee: ' + newRole.role_ID);

                    if (role.role_ID === newRole.role_ID) {
                        console.log('stays there');
                        remove = false;
                    }
                }
                console.log(remove);
                if (remove) {
                    console.log('gets removed');
                    removeRoles.push(role);
                }
            }

            console.log('toRemove Roles:');
            console.log(removeRoles);

            for (let role of removeRoles) {
                this.employeeService.removeRole(this.originEmployee.employee_ID, role.role_ID);
            }


            // define which roles have to be added and add them
            for (let newRole of employeeRoles) {
                let add = true;
                for (let role of this.originEmployee.roles) {
                    if (role.role_ID === newRole.role_ID) {
                        add = false;
                    }
                }

                if (add) {
                    console.log('gets added');
                    addRoles.push(newRole);
                }
            }

            console.log('toAdd Roles:');
            console.log(addRoles);

            for (let role of addRoles) {
                this.employeeService.addRole(this.originEmployee.employee_ID, role.role_ID);
            }
        });

        this.events.publish('updateEmployees', this.originEmployee);
        this.events.publish('showEmployees', this.originEmployee);


        /*
        // delete all roles from origin employee
        let oldRoles: Role[];
        oldRoles = this.originEmployee.roles;

        if (oldRoles !== undefined) {
            oldRoles.forEach(role => {
                this.employeeService.removeRole(this.originEmployee.employee_ID, role.role_ID);
            });
        }

        // add new roles to origin employee
        if (this.employee.roles !== undefined) {
            this.employee.roles.forEach(role => {
                this.employeeService.addRole(this.originEmployee.employee_ID, role.role_ID);
            });
        }*/
    }

    //Fehlermeldungen anhand der verschiedenen Fehler:
    validation_messages = {
        'email': [
            {type: 'required', message: 'Bitte eine gültige Email eintragen.'},
            {type: 'email', message: 'Die Email Adresse muss gültig sein.'},
            {type: 'pattern', message: 'Die Email Adresse muss folgendes Format haben: xxxx@xx.xx'},
            {type: 'maxlength', message: 'Die Email darf maximal aus 40 Zeichen bestehen.'}
        ],
        'name': [
            {type: 'required', message: 'Bitte ein gültigen Namen eintragen.'},
            {type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Name darf maximal aus 20 Zeichen bestehen.'}
        ],
        'phonenumber': [
            {type: 'minlength', message: 'Die Telefonnummer muss mindestens aus 7 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Die Telefonnummer darf maximal aus 20 Zeichen bestehen.'}
        ],
        'place': [
            {type: 'required', message: 'Bitte ein gültigen Ort eintragen.'},
            {type: 'minlength', message: 'Der Ortsname muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Ortsname darf maximal aus 30 Zeichen bestehen.'}
        ],
        'street': [
            {type: 'required', message: 'Bitte eine gültige Straße eintragen.'},
            {type: 'minlength', message: 'Der Straßenname muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Straßenname darf maximal aus 50 Zeichen bestehen.'}
        ],
        'housenumber': [
            {type: 'required', message: 'Bitte eine gültige Hausnummer eintragen.'},
            {type: 'maxlength', message: 'Die Hausnummer darf maximal aus 10 Zeichen bestehen.'}
        ],
        'postcode': [
            {type: 'required', message: 'Bitte eine gültige PLZ eintragen.'},
            {type: 'minlength', message: 'Der PLZ muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Die PLZ darf maximal aus 10 Zeichen bestehen.'}
        ],
        'address_additional': [
            {type: 'minlength', message: 'Der Addresszusatz muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Addresszusatz darf maximal aus 30 Zeichen bestehen.'}
        ],
    }

}