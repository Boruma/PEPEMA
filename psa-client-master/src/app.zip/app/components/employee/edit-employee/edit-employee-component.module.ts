import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { EditEmployeeComponent } from './edit-employee.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
  ],
  exports: [
    EditEmployeeComponent
  ],
  declarations: [
    EditEmployeeComponent
  ], 
})

export class EditEmployeeComponentModule { }
