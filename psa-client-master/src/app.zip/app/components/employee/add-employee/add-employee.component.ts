import {Component, OnInit, ErrorHandler} from '@angular/core';
import {FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import {EmployeeService} from '../../../services/employee.service';
import {ErrorhandlingService} from 'src/app/services/errorhandling.service';
import {Address} from 'src/app/models/address';
import {Employee} from 'src/app/models/employee';
import {LoadingController} from '@ionic/angular';
import {Events} from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';

@Component({
    selector: 'app-add-employee',
    templateUrl: './add-employee.component.html',
    styleUrls: ['./add-employee.component.scss'],
})

export class AddEmployeeComponent implements OnInit {

    
    createForm: FormGroup;
    addressForm: FormGroup;
    employee: Employee = {} as Employee;
    private showAdrDelActivate:boolean = null;
    private showAdressDeleted:boolean = false;

    addressToggle = false;
    attemptedSubmit = false;
    employeeAdded = false;

    constructor(public formBuilder: FormBuilder,
                private employeeService: EmployeeService,
                private errorService: ErrorhandlingService,
                private loadingController: LoadingController,
                // private manageEmployee: ManageEmployeePage,
                private events: Events,
                private router: Router,
                ) {

        this.employee.address = {} as Address;
        this.createForm = this.formBuilder.group({
            name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
            email: ['', [Validators.email, Validators.minLength(5), Validators.maxLength(40),
                Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
            phonenumber: ['', [Validators.minLength(5), Validators.maxLength(20)]],
            locker: ['',],
            toggleAddress: ['',]
        });
        this.addressForm = this.formBuilder.group({
            place: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(30)]],
            street: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
            housenumber: ['', [Validators.required, Validators.maxLength(10)]],
            postcode: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
            address_additional: ['', [Validators.minLength(2), Validators.maxLength(30)]]
        });
        this.addressForm.disable();
    }

    // error messages for different errors
    validation_messages = {
        email: [
            {type: 'required', message: 'Bitte eine gültige Email eintragen.'},
            {type: 'email', message: 'Die Email Adresse muss gültig sein.'},
            {type: 'pattern', message: 'Die Email Adresse muss folgendes Format haben: xxxx@xx.xx'},
            {type: 'maxlength', message: 'Die Email darf maximal aus 40 Zeichen bestehen.'}
        ],
        name: [
            {type: 'required', message: 'Bitte ein gültigen Namen eintragen.'},
            {type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Name darf maximal aus 20 Zeichen bestehen.'}
        ],
        phonenumber: [
            {type: 'minlength', message: 'Die Telefonnummer muss mindestens aus 7 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Die Telefonnummer darf maximal aus 20 Zeichen bestehen.'}
        ],
        place: [
            {type: 'required', message: 'Bitte ein gültigen Ort eintragen.'},
            {type: 'minlength', message: 'Der Ortsname muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Ortsname darf maximal aus 30 Zeichen bestehen.'}
        ],
        street: [
            {type: 'required', message: 'Bitte eine gültige Straße eintragen.'},
            {type: 'minlength', message: 'Der Straßenname muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Straßenname darf maximal aus 50 Zeichen bestehen.'}
        ],
        housenumber: [
            {type: 'required', message: 'Bitte eine gültige Hausnummer eintragen.'},
            {type: 'maxlength', message: 'Die Hausnummer darf maximal aus 10 Zeichen bestehen.'}
        ],
        postcode: [
            {type: 'required', message: 'Bitte eine gültige PLZ eintragen.'},
            {type: 'minlength', message: 'Der PLZ muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Die PLZ darf maximal aus 10 Zeichen bestehen.'}
        ],
        address_additional: [
            {type: 'minlength', message: 'Der Addresszusatz muss mindesten aus 2 Zeichen bestehen.'},
            {type: 'maxlength', message: 'Der Addresszusatz darf maximal aus 30 Zeichen bestehen.'}
        ],
    };

    ngOnInit() {
    }

    createEmployee() {
        this.attemptedSubmit = true;
        if (this.createForm.valid && (!this.addressToggle || this.addressForm.valid)) {
            let loading: HTMLIonLoadingElement;
            this.loadingController.create({
                spinner: 'circles'
            }).then(res => {
                loading = res;
                loading.present();
                this.employeeService.createEmployee(this.employee)
                    .then(newEmployee => {
                        this.attemptedSubmit = false;
                        this.markFieldsReset();

                        this.events.publish('updateEmployees', (newEmployee)); //reset Employee-List in list-employee

                        this.employee = {} as Employee;
                        this.employee.address = {} as Address; 
                        this.router.navigate(['users/employees']);     
                        loading.dismiss();
                    })
                    .catch(error => {
                        // Errorhandling
                        this.errorService.error(error);
                        loading.dismiss();
                    });
            });
        } else {
            this.markFieldsDirty();
        }
    }

    public showEmployee(employee) {
        let navigationExtras: NavigationExtras = {
          state: {
            employee: employee,
            url: this.router.url
          }
        };
        this.router.navigate(['users/employees/show'], navigationExtras);
        //this.router.navigate([this.router.url + '/show'], navigationExtras);
      } 
      
    //   public showListEmployee(){
    //       this.router.navigate(['users/employees']);      
    //   }

    toggleAddressForm() {
        if (this.addressToggle) {
            if(this.showAdrDelActivate == null){
                this.showAdrDelActivate = true;
            }
            this.addressForm.disable();
        } else {
            this.addressForm.enable();
        }
    }

    toggleDeleteMessage(){
        if(this.showAdrDelActivate == true){
            if(this.showAdressDeleted){
                this.showAdressDeleted = false;
            } else {
                this.showAdressDeleted = true;
            }
        }

    }

    markFieldsDirty() {
        for (const field in this.createForm.controls) {
            this.createForm.controls[field].markAsDirty();
        }
        if (this.addressToggle) {
            for (const field2 in this.addressForm.controls) {
                this.addressForm.controls[field2].markAsDirty();
            }
        }
    }

    markFieldsReset() {
        for (const field in this.createForm.controls) {
            this.createForm.controls[field].reset();
        }
        if (this.addressToggle) {
            for (const field2 in this.addressForm.controls) {
                this.addressForm.controls[field2].reset();
            }
        }
    }
}
