import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { ListEmployeesComponent } from './list-employees.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
  ],
  exports: [
    ListEmployeesComponent
  ],
  declarations: [
    ListEmployeesComponent
  ], 
})

export class ListEmployeesComponentModule { }
