import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { EmployeeService } from '../../../services/employee.service';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { Employee } from 'src/app/models/employee';
import { Address } from 'src/app/models/address';
import { LoadingController } from '@ionic/angular';
//import { ManageEmployeePage } from '../../../employee/manage-employee/manage-employee.page';
//import { ManageEmployeeAppViewPage } from '../../../employee/manage-employee-app-view/manage-employee-app-view.page';
import { Router, NavigationExtras } from '@angular/router';

import { Events, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.scss'],
})
export class ListEmployeesComponent implements OnInit {

  // list of all employees
  private employees: Employee[] = new Array();
  private filterdEmployees: Employee[];
  public searchTerm: string = "";
  private markedEmployee: Employee;

  // index of current employee
  public listIndex: number;
  private listIsEmpty: boolean;

  constructor(
    public formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private errorService: ErrorhandlingService,
    private loadingController: LoadingController,
    //   private manageEmployee: ManageEmployeeAppViewPage,
    private events: Events,
    private changeDetector: ChangeDetectorRef,
    private alertCtrl: AlertController,
    private router: Router
  ) {
    this.markedEmployee = null;
    this.events.subscribe('deleteEmployee', (employee) => {
      this.deleteEmployee(employee.employee_ID);
      this.listIndex = -1;
      this.searchTerm = "";
    });
    //If a employee will be chaneged or a new one will be added
    this.events.subscribe('updateEmployees', (employee) => {
      this.markedEmployee = employee;
      this.searchTerm = "";
      this.getAllEmployees();
    });
  }

  ngOnInit() {
    this.listIsEmpty = true;
    this.getAllEmployees();
  }
  
  ionViewDidEnter() {
    this.listIndex = -1;
    this.searchTerm = "";
  }

  // reads in all employees and saves them to the array
  async getAllEmployees() {
    this.employeeService.getEmployees().then(resEmployees => {
      if (resEmployees.length != 0) {
        this.employees = resEmployees;
        this.filterdEmployees = resEmployees;
        this.listIsEmpty = false;
        this.listIndex = this.getIndex(this.markedEmployee);
      }
    })
      .catch(error => {
        this.errorService.error(error);
      });
  }

  public deleteEmployee(id) {
    // delete in server
    this.employeeService.deleteEmployee(id);
    // delete in array
    this.employees.splice(this.employees.findIndex(employee => employee.employee_ID == id), 1);
    //reduces the current filtered EmployeeList
    this.setFilteredEmployees();
    //show "Keine Personen enthalten"
    if (this.employees.length == 0) {
      this.listIsEmpty = true;
    }
    this.router.navigate(['users/employees']);
  }

  // returns array index of employee
  private getIndex(employee: Employee) {
    for (const index in this.filterdEmployees) {
      if (this.filterdEmployees[index].employee_ID === employee.employee_ID) {
        return this.filterdEmployees.indexOf(this.filterdEmployees[index]);
      }
    }
    return -1;
  }

  private setFilteredEmployees() {
    this.filterdEmployees = this.filterEmployee(this.searchTerm);
  }

  private filterEmployee(searchTerm) {
    return this.employees.filter(employee => {
      return employee.name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    });
  }

  public showEmployee(employee) {
    let navigationExtras: NavigationExtras = {
      state: {
        employee: employee,
        url: this.router.url
      }
    };
    this.router.navigate([this.router.url + '/show'], navigationExtras);
  }

  public showEmployeeDesktop(employee) {
    this.events.publish('showEmployee', (employee));
}

  public addEmployee() {
    this.router.navigate([this.router.url + '/add']);
  }

  public editEmployee(employee) {
    let navigationExtras: NavigationExtras = {
      state: {
        employee: employee,
        url: this.router.url
      }
    };
    // console.log(employee);
    this.router.navigate([this.router.url + '/edit'], navigationExtras);
  }

  async presentAlertConfirmDelete(employee) {
    const alert = await this.alertCtrl.create({
      header: 'Löschen',
      message: '<strong>' + employee.name + '</strong> wirklich löschen?',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {

          }
        }, {
          text: 'Okay',
          handler: () => {
            let id = employee.employee_ID;
            this.deleteEmployee(id);
          }
        }
      ]
    });

    await alert.present();
    let result = await alert.onDidDismiss();
  }
}