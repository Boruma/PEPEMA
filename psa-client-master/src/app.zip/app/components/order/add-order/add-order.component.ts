import { Component, OnInit } from '@angular/core';
import { LoadingController } from "@ionic/angular";
import { Supplier } from 'src/app/models/Supplier';
import { SupplierService } from '../../../services/supplier.service';
import { OrderService } from 'src/app/services/order.service';
import { PsaService } from "../../../services/psa.service";
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { AlertController } from '@ionic/angular';
import { Events } from '@ionic/angular';
import { PsatemplateService } from 'src/app/services/psatemplate.service';
import { Pe } from 'src/app/models/pe';
import { PPE } from 'src/app/models/ppe';
import { Order } from 'src/app/models/order';
import { size } from 'src/app/models/size';
import { size_range } from 'src/app/models/size_range';
import { Role } from 'src/app/models/Role';
import { Observable, of, throwError } from 'rxjs';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { CreatePsaComponent } from '../../psa/create-psa/create-psa.component';

@Component({
  selector: 'app-add-order',
  templateUrl: './add-order.component.html',
  styleUrls: ['./add-order.component.scss'],
})
export class AddOrderComponent implements OnInit {

  // private newOrder: Order = <Order>{};
  private newOrder: Order = null; //created by orderService todo: erst erstellen, dann supplier hinzufügen
  //private finalOrder: Order = new Order();
  private orderNumber: number;
  private orderInProcess = false;

  private supplier: Supplier[] = new Array();
  // private defaultSelectQuestion:number; //-1 no Selection, 0=first element
  // private selectedQuestion:Supplier;

  private suppListIsEmpty: boolean = true;
  private supplIsSelected: boolean = false;

  private peSelected: boolean = false;
  private selectedPsaTemplate: Pe = <Pe>{}; //selectet pe

  private newPpes: PPE[] = new Array<PPE>();
  private newPpesIsEmpty: boolean = true;



  // public dataUpdatet: any = null;
  //public newPpeData: any = new Array<any>();


  constructor(
    private route: ActivatedRoute,
    private errorService: ErrorhandlingService,
    private supplierService: SupplierService,
    private orderService: OrderService,
    private psaService: PsaService,
    public alertController: AlertController,
    public router: Router,
    private loadingController: LoadingController,


  ) {


    //if u dont want any default selection

  }

  ngOnInit() {
    this.getAllSuppliers();
    this.route.params.forEach(params => {
      // This will be triggered every time the params change
      // Add your code to reload here. i.e.
      this.getNewOrderData();
      this.getNewPpesData();
    });
    this.setNewOrder();
  }

  //check if a order is still in process
  getNewOrderData() {
    // const loading = await this.loadingController.create({
    //   message: 'Loading'
    // });
    // await loading.present();
    this.orderService.orderDataUpdatet.subscribe(observerData => {
      this.newOrder = observerData;
      if (this.newOrder == null) {
        console.log("order = null");
        this.orderInProcess = false;
        this.supplIsSelected = false;

      } else {
        console.log("order != null");
        this.orderInProcess = true;

        if (this.newOrder.supplier != null) {
          this.supplIsSelected = true;
        } else {
          console.log("noch kein supplier")
          this.supplIsSelected = false;
        }
      }
    }, err => {
      console.log(err); //todo?
    });
  }

  //sets the order if there is none
  private setNewOrder() {
    if (this.newOrder == null) {
      this.newOrder = new Order();
      this.orderService.setNewOrder(this.newOrder);
      this.orderInProcess = true;
    }
  }

  async getNewPpesData() {
    const loading = await this.loadingController.create({
      message: 'Loading'
    });
    await loading.present();
    this.orderService.ppesDataUpdatet
      .subscribe(observerData => {
        console.log("addorder.. observer: new PPE");
        console.log(observerData);
        this.newPpes = observerData;
        if (this.newPpes == null) {
          console.log("addorder.. newPpes = null");
          this.newPpesIsEmpty = true;
        } else if (this.newPpes) {
          console.log("addorder.. newPpes != null");
          this.newPpesIsEmpty = false;
        }


        loading.dismiss();
      }, err => {
        console.log(err);
        loading.dismiss();
      });
  }



  private getAllSuppliers() {
    this.supplierService.getSuppliers().then(resSupplier => {
      if (resSupplier.length != 0) {
        this.supplier = resSupplier;
        this.suppListIsEmpty = false;
      }
    })
      .catch(error => {
        this.errorService.error(error);
      });
  }

  private changeSupplier($event) {
    let suppl = this.getSupplier($event);
    if (suppl != null) {
      //set first Supplier
      if (this.newOrder.supplier == null) {
        // this.newOrder = <Order>{};
        this.newOrder.supplier = suppl;
        this.newOrder.supplier_ID = suppl.supplier_ID;
        this.orderService.setNewOrder(this.newOrder);
        this.supplIsSelected = true;
      }
      //change supplier? 
      else {
        // this.presentAlertChangeSupplier(suppl);
      }
    }
  }

  private setNewSupplier(supplier) {
    this.newOrder.supplier = supplier;
    this.newOrder.supplier_ID = supplier.supplier_ID;
    this.orderService.setNewOrder(this.newOrder);
    this.supplIsSelected = true;
    this.orderService.clearNewPpes();
  }

  async presentAlertChangeSupplier(supplier) {
    const alert = await this.alertController.create({
      header: 'Lieferante ändern',
      message: 'Lieferante wirklich auf ' + supplier.name + ' ändern? Alle Artikel werden gelöscht.',
      buttons: [
        {
          text: 'Abbrechen',
          // cssClass: 'secondary',
          handler: () => {
          }
        }, {
          text: 'Okay',
          handler: () => {
            this.setNewSupplier(supplier);
          }
        }
      ]
    });

    await alert.present();
    let result = await alert.onDidDismiss();
  }

  // unused
  // private getSupplierIndex(supplier) {
  //   for (const index in this.supplier) {
  //     if (this.supplier[index].supplier_ID === supplier.supplier_ID) {
  //       return this.supplier.indexOf(this.supplier[index]);
  //     }
  //   }
  //   return -1;
  // }

  private getSupplier<Supplier>($event) {
    for (var suppl of this.supplier) {
      if (suppl.supplier_ID == $event.detail.value) {
        return suppl;
      }
    }
    return null;
  }

  private openCreatePsa() {
    if (this.newOrder != null) {
      let navigationExtras: NavigationExtras = {
        state: {
          stockType: 1,
          supplier: this.newOrder.supplier,
          order_ID: this.newOrder.order_ID,
          url: this.router.url,
        }
      };
      console.log(navigationExtras);
      this.router.navigate([this.router.url + '/createPsa'], navigationExtras);
    } else {
      // todo? Fehler?
    }
  }


  private submitAddOrder() {
    this.createFinalOrder();
  }

  private createFinalOrder() {
    console.log("createOrder()");
    console.log(this.newOrder);
    console.log(this.newOrder.supplier_ID);
    if (this.newOrder != null && this.newOrder.supplier_ID != null &&
      this.newPpes != null && this.newPpes.length != 0) {
      console.log("createOrder() drin....");
      let loading: HTMLIonLoadingElement;
      this.loadingController.create({
        spinner: "circles"
      }).then(res => {
        loading = res;
        loading.present();

        this.orderService.createOrder(this.newOrder).then(res => {
          //this.finalOrder = res; //enthält order_ID, supplier_ID und supplier
          this.orderNumber = res.order_ID;
          this.createFinalPpes();
          loading.dismiss();
        })
          .catch(error => {
            this.errorService.error(error);
            loading.dismiss();
          });
      });
    } else {
      //todo: Fehler - ungültige order?
    }
  }

  private createFinalPpes() {
    console.log("createPpes()");
    console.log(this.orderNumber);
    if (this.newPpes != null && this.newPpes.length != 0) {
      if (this.orderNumber != null) {
        for (var ppe of this.newPpes) {
          ppe.order_ID = this.orderNumber;
          this.psaService.createPsa(ppe).then(res => {
            this.deleteFromNewPpes(ppe.pe_ID);
            console.log("ppe erstellt");
            console.log(ppe);
          })
            .catch(error => {
              this.errorHandligCreatetOrder();
              this.errorService.error(error);
            });
        }
      }
      this.finishCreateOrder();
    } else {
      //todo: Fehler, keine Ppe enthalten?
    }
  }

  public deleteFromNewPpes(id) {
    if (this.newPpes != null) {
      this.newPpes.splice(this.newPpes.findIndex(ppe => ppe.pe_ID == id), 1);
    }
    if (this.newPpes.length = 0) {
      this.newPpes = null;
    }
  }

  private errorHandligCreatetOrder() {
    //todo bereits erstellte order löschen
    //this.createOrderIsValid = false;
  }

  private finishCreateOrder() {
    //if(this.createOrderIsValid && this.newPps == null){
    // console.log(this.finalOrder);
    console.log(this.newPpes)
    this.orderService.setNewOrder(null);
    this.orderService.clearNewPpes();
    this.psaService.resetPpeCount();
    this.presentAlertConfirmCreate();
    //}else {
    // todo  
    // }
  }

  async presentAlertConfirmCreate() {
    const alert = await this.alertController.create({
      header: 'Erfolgreich erstellt!',
      message: '<strong> Bestellliste ' + this.orderNumber + ' </strong>wurde erstellt.',
      buttons: [
        {
          text: 'Jetzt Bestellen',
          // cssClass: 'secondary',
          handler: () => {
            this.showNewOrder();
          }
        }, {
          text: 'Okay',
          handler: () => {
            this.showOrders();
          }
        }
      ]
    });

    await alert.present();
    let result = await alert.onDidDismiss();
  }

  private cancelOrder() {
    this.orderService.setNewOrder(null);
    this.orderService.clearNewPpes();
    this.psaService.resetPpeCount();
    this.router.navigate(['users/orders']);
  }

  async presentAlertConfirmCancel() {
    const alert = await this.alertController.create({
      header: 'Bestellung Abbrechen',
      message: 'Wirklich abbrechen und alle Artikel löschen?',
      buttons: [
        {
          text: 'Nicht abbrechen',
          // cssClass: 'secondary',
          handler: () => {
          }
        }, {
          text: 'Okay',
          handler: () => {
            this.cancelOrder();
          }
        }
      ]
    });

    await alert.present();
    let result = await alert.onDidDismiss();
  }

  //for start ordermail or set orderdata
  private showNewOrder() {

    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.orderService.getOrder(this.orderNumber).then(res => {
        //this.finalOrder = res; //enthält order_ID, supplier_ID und supplier

        console.log(res);
        loading.dismiss();
        let navigationExtras: NavigationExtras = {
          state: {
            order: res,
            url: this.router.url
          }
        };
        this.router.navigate(['users/orders/show'], navigationExtras);
      })
        .catch(error => {
          this.errorService.error(error);
          loading.dismiss();
        });
    });

  }

  private showOrders() {
    this.router.navigate(['users/orders']);
  }



}
