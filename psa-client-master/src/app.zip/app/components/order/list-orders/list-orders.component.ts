/*
* todo: filter, getAllOrders() + deleteOrder serviceMethode einkommentieren
*
*/

import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderService } from '../../../services/order.service';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { Order } from 'src/app/models/order';
import { LoadingController } from '@ionic/angular';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { Events, AlertController } from '@ionic/angular';
import { Supplier } from 'src/app/models/Supplier';

@Component({
  selector: 'app-list-orders',
  templateUrl: './list-orders.component.html',
  styleUrls: ['./list-orders.component.scss'],
})
export class ListOrdersComponent implements OnInit {

  private orders: Order[] = new Array<Order>();
  private filteredOrders: Order[] = new Array<Order>();
  private notOrderedOrders: Order[] = new Array<Order>();
  private orderedOrders: Order[] = new Array<Order>();
  private deliveredOrders: Order[] = new Array<Order>();
  private searchTerm: string = "";
  private markedOrder: Order;
  // public listIndex: number;
 //  private listIsEmpty: boolean;

  constructor(
    public formBuilder: FormBuilder,
    private orderService: OrderService,
    private errorService: ErrorhandlingService,
    private loadingController: LoadingController,
    private events: Events,
    private changeDetector: ChangeDetectorRef,
    private alertCtrl: AlertController,
    private router: Router,
    private route: ActivatedRoute
  ) {

    this.getCheck();

    this.markedOrder = null;
    this.events.subscribe('deleteOrder', (order) => {
      console.log("subscribe deleteOrder" + order);
      this.deleteOrder(order);
      // this.listIndex = -1;
      this.searchTerm = "";
    });
    //If a employee will be chaneged or a new one will be added
    this.events.subscribe('updateOrders', (order) => {
      this.markedOrder = order;
      this.searchTerm = "";
      this.getAllOrders();
    });
  }

  ngOnInit() {
    // this.listIsEmpty = true;
    this.route.params.forEach(params => {
      // This will be triggered every time the params change
      // Add your code to reload here. i.e.
      this.getAllOrders();

    });

  }


  async getAllOrders() {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.orderService.getOrders().then(resOrders => {
        console.log(resOrders);
        if (resOrders.length != 0) {
          console.log(resOrders);
          this.orders = resOrders;
          this.filteredOrders = resOrders;
          this.sortOrders();
          // this.listIsEmpty = false;
          // this.listIndex = this.getIndex(this.markedOrder);
        }
        
        loading.dismiss();
      })
        .catch(error => {
          this.errorService.error(error);
          loading.dismiss();
        });
    });
    console.log("getAllOrders");
  }

  async getCheck(){
    this.orderService.getOrders().then(res =>{
      console.log(res);
      
    }).catch(         error =>{
      this.errorService.error(error);  
  });

  }

  private sortOrders(){
    console.log("sortAllOrders");
    let length = this.filteredOrders.length;
    if(this.filteredOrders != null && length != 0){
      this.notOrderedOrders.length = 0;
      this.orderedOrders.length = 0;
      this.deliveredOrders.length = 0;
      console.log(this.filteredOrders);
      console.log(this.notOrderedOrders);
      console.log(this.orderedOrders);
      console.log(this.deliveredOrders);
      for(var order of this.filteredOrders){
        if(order.state === "ordered"){
          
          console.log("++bestellt - ID: " + order.order_ID);
          console.log(order);
          this.orderedOrders.push(order);       
        }
        if(order.state === "delivered"){
          console.log("++geliefert - ID: " + order.order_ID);
          console.log(order);
          this.deliveredOrders.push(order);
        } else if(order.state == null){
          console.log("++noch nicht Bestellt - ID: " + order.order_ID);
          console.log(order);
          this.notOrderedOrders.push(order);
        }
      }
      this.filteredOrders.length = 0;
    }
  }

  public deleteOrder(order) {
    console.log("delete order ID: " + order.id);
    // delete in server
    this.orderService.deleteOrder(order.id); 

    // delete in array
    if(order.state === "ordered"){
      this.orderedOrders.splice(this.orders.findIndex(foundOrder => foundOrder.order_ID == order.id), 1);      
    }
    if(order.state === "delivered"){
      this.deliveredOrders.splice(this.orders.findIndex(foundOrder => foundOrder.order_ID == order.id), 1);      
    } else {
      this.notOrderedOrders.splice(this.orders.findIndex(foundOrder => foundOrder.order_ID == order.id), 1);      
    }

    //this.setFilteredOrders();
    //show "Keine Order enthalten"
    // if (this.orders.length == 0) {
    //   this.listIsEmpty = true;
    // }
    //this.router.navigate(['users/orders']);
  }

  // ********* Filtern nicht umgesetzt ************
  // returns array index of order
  // private getIndex(order: Order) {
  //   for (const index in this.filteredOrders) {
  //     if (this.filteredOrders[index].order_ID === order.order_ID) {
  //       return this.filteredOrders.indexOf(this.filteredOrders[index]);
  //     }
  //   }
  //   return -1;
  // }
  //todo - filtern
  // private setFilteredOrders() {
  //   this.filteredOrders = this.orders;
  //   this.sortOrders();
  //   //todo =this.filterOrder(this.searchTerm);
  // }
  //todo -  wonach filtern? Order ID? Suppliernamen
  // private filterOrder(searchTerm) {
  //   return this.orders.filter(order => {
  //     return order.order_ID.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
  //   });
  // }

  public showOrder(order) {
    console.log(order);
    let navigationExtras: NavigationExtras = {
      state: {
        order: order,
        url: this.router.url
      }
    };

    this.router.navigate([this.router.url + '/show'], navigationExtras);
  }

  public addOrder() {
    this.router.navigate([this.router.url + '/add']);
  }

  public editOrder(order) {
    let navigationExtras: NavigationExtras = {
      state: {
        order: order,
        url: this.router.url
      }
    };
    this.router.navigate([this.router.url + '/edit'], navigationExtras);
  }

  async presentAlertConfirmDelete(order) {
    const alert = await this.alertCtrl.create({
      header: 'Löschen',
      message: '<strong>Bestellung ' + order.order_ID + '</strong> wirklich löschen?',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (cancel) => {

          }
        }, {
          text: 'Okay',
          handler: () => {
            this.deleteOrder(order);

          }
        }
      ]
    });

    await alert.present();
    let result = await alert.onDidDismiss();
  }
}
