import { Component, OnInit } from '@angular/core';
import { Order } from '../../../models/order';
import { ActivatedRoute, Router, NavigationExtras } from '@angular/router';
import { ErrorhandlingService } from '../../../services/errorhandling.service';
import { Events, AlertController } from '@ionic/angular';
import { OrderService } from '../../../services/order.service';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { LoadingController } from '@ionic/angular';
import { Supplier } from 'src/app/models/Supplier';


@Component({
  selector: 'app-show-order',
  templateUrl: './show-order.component.html',
  styleUrls: ['./show-order.component.scss'],
})
export class ShowOrderComponent implements OnInit {

  private incomingUrl: String;
  private order: Order = new Order();

  private showSetOrderData = false;
  private orderDateForm: FormGroup;

  constructor(
    private alertCtrl: AlertController,
    private loadingController: LoadingController,
    private orderService: OrderService,
    private errorService: ErrorhandlingService,
    public formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.orderDateForm = this.formBuilder.group({
      orderDate: new FormControl('', Validators.compose([

      ])),
    });
  }

  ngOnInit() {
    this.route.params.forEach(params => {
      // This will be triggered every time the params change
      // Add your code to reload here. i.e.
      this.getRouterData();

    });

  }

  private getRouterData() {
    this.order = this.router.getCurrentNavigation().extras.state.order;
    console.log(this.order);
    this.incomingUrl = this.router.getCurrentNavigation().extras.state.url;
  }

  private changeShowSetOrderData() {
    if (this.showSetOrderData) {
      this.showSetOrderData = false;
    } else {
      this.showSetOrderData = true;
    }
  }


  private setOrderData() {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.updateDate();
      this.updateState("ordered");
      loading.dismiss();
    });

  }

  private updateDate() {
    this.orderService.orderCommited(this.order.order_ID, this.order.orderdate).then(resOrders => {
    })
      .catch(error => {
        this.errorService.error(error);
      });
  }

  private updateState(state: string) {
    this.order.state = state;
    console.log(this.order);
    this.orderService.updateOrder(this.order).then(resOrders => {
      this.presentAlertConfirmOrdered();
    })
      .catch(error => {
        this.errorService.error(error);
      });
  }

  async presentAlertConfirmOrdered() {
    const alert = await this.alertCtrl.create({
      header: 'Bestellt!',
      message: 'Bestellung <strong>' + this.order.order_ID + '</strong>  wurde bestellt.',
      buttons: [
        {
          text: 'Okay',
          handler: () => {
            this.showOrders();

          }
        }
      ]
    });

    await alert.present();
    let result = await alert.onDidDismiss();
  }

  private showOrders() {
    this.router.navigate(['users/orders']);
  }






  async presentAlertConfirmDelete() {
    console.log("aaa");
    const alert = await this.alertCtrl.create({
      header: 'Löschen',
      message: '<strong>Bestellung ' + this.order.order_ID + '</strong> wirklich löschen?',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (cancel) => {

          }
        }, {
          text: 'Okay',
          handler: () => {
            this.deleteOrder();

          }
        }
      ]
    });
    await alert.present();
    let result = await alert.onDidDismiss();
  }

  private deleteOrder(){
    this.orderService.deleteOrder(this.order.order_ID);
  //with routing users/orders all orders will be reloaded
    this.router.navigate(['users/orders']); 
}

    //********* todo *******

  //validierung Datum?

  //wenn die Bestellung noch nicht bestellt wurde, sollen noch Artikel hinzugefügt werden können
  private openCreatePsa(){
      if (this.order != null) {
        let navigationExtras: NavigationExtras = {
          state: {
            stockType: 1,
            supplier: this.order.supplier,
            order_ID: this.order.order_ID,
            url: this.router.url,
          }
        };
        console.log(navigationExtras);
        this.router.navigate([this.router.url + '/createPsa'], navigationExtras);
      } else {
        // todo? Fehler?
      }
  }

  //Sollen die ppes wirklich bearbeitet werden? Alternative: löschen und neu hinzufügen
  private editPpeFromOrder() {
    console.log("todo");
  }

  //todo - just possible if supplier has got a mail-address
  private startOrderMail() {
    console.log("todo");
  }
}
