import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-psa-page',
  templateUrl: './show-psa.page.html',
  styleUrls: ['./show-psa.page.scss'],
})
export class ShowPsaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
