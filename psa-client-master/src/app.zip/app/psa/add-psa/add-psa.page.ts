import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray, Validators } from '@angular/forms';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { PsaService } from "../../services/psa.service";
import { PPE } from 'src/app/models/ppe';
import { Property } from 'src/app/models/property';
import { size } from 'src/app/models/size';
import { size_range } from 'src/app/models/size_range';
import { AlertController } from '@ionic/angular';
import { Router } from "@angular/router";
import { LoadingController } from "@ionic/angular";

@Component({
  selector: 'app-add-psa-page',
  templateUrl: './add-psa.page.html',
  styleUrls: ['./add-psa.page.scss'],
})
export class AddPsaPage implements OnInit {

  constructor() {

  }

  ngOnInit() {

  }

  // public psaForm: FormGroup;
  // templates: any;
  // template: any;
  // size: size;
  // sn: any;
  // ppe: PPE = <PPE>{};


  // constructor(public formBuilder: FormBuilder,
  //   private psaService: PsaService,
  //   private errorService: ErrorhandlingService,
  //   public alertController: AlertController,
  //   public router: Router,
  //   private loadingController: LoadingController, ) {

  //   this.ppe.properties = Array<Property>();
  //   this.ppe.size_ranges = Array<size_range>();
  //   this.psaForm = this.formBuilder.group({

  //     sn: new FormControl('', Validators.compose([
  //       Validators.required,
  //       Validators.minLength(2)
  //     ])),
  //     pn: new FormControl('', Validators.compose([
  //       Validators.required,
  //       Validators.minLength(2)
  //     ])),
  //     comment: new FormControl('', Validators.compose([
  //       Validators.maxLength(150),
  //     ])),
  //     commissioningdate: new FormControl('', Validators.compose([

  //     ])),
  //     state: new FormControl('', Validators.compose([
  //       Validators.maxLength(30),
  //     ])),

  //     properties: new FormArray([]),
  //   });
  //   this.getTemplates();
  // }

  // get properties(): FormArray { return this.psaForm.get('properties') as FormArray; }


  // createProperty(property: Property): FormControl {
  //   switch (property.type) {
  //     case 'upValueRange':
  //       return new FormControl('', Validators.compose([
  //         Validators.min(0)
  //       ]));
  //       break;
  //     case 'downValueRange':
  //       return new FormControl('', Validators.compose([
  //         Validators.min(0)
  //       ]));
  //       break;
  //     case 'value':
  //       return new FormControl('', Validators.compose([
  //         Validators.min(0)
  //       ]));
  //       break;
  //     case 'date':
  //       return new FormControl('', Validators.compose([

  //       ]));
  //       break;
  //     case 'text':
  //       return new FormControl('', Validators.compose([
  //         Validators.minLength(2)
  //       ]));
  //       break;
  //     case 'intervall':
  //       return new FormControl('', Validators.compose([
  //         Validators.min(1)
  //       ]));
  //       break;
  //   }

  // }

  // addProperty(property: Property) {
  //   if (property != null) {
  //     this.properties.push(this.createProperty(property));
  //   }
  //   if (property != null) {
  //     this.ppe.properties.push(new Property(property));
  //   }
  // }

  // ngOnInit() {

  // }

  // async getTemplates() {
  //   let loading: HTMLIonLoadingElement;
  //   this.loadingController.create({
  //     spinner: "circles"
  //   }).then(res => {
  //     loading = res;
  //     loading.present();

  //     this.psaService.getPes().then(data => {
  //       this.templates = data;

  //     }).catch(error => {
  //       //Errorhandling here
  //       this.errorService.error(error);
  //     });

  //     loading.dismiss();
  //   });


  // }

  // addTemplateToPsa($event) {

  //   let loading: HTMLIonLoadingElement;
  //   this.loadingController.create({
  //     spinner: "circles"
  //   }).then(res => {
  //     loading = res;
  //     loading.present();

  //     this.psaService.getPe($event.detail.value).then(template => {

  //       for (var t of this.templates) {
  //         if (t.pe_ID == $event.detail.value) {

  //           this.ppe.pe = t;

  //         }
  //       }



  //       //this.ppe.pe = template;
  //       this.ppe.pe_ID = $event.detail.value;
  //       this.ppe.order_ID = 1;

  //       this.ppe.pe.properties.forEach(property => {
  //         this.addProperty(property);
  //       });

  //       this.ppe.pe.size_ranges.forEach(sr => {

  //         this.ppe.size_ranges.push(new size_range(sr.sizes[0], sr));

  //       });

  //       console.log(this.ppe.size_ranges);




  //     }).catch(error => {

  //       this.errorService.error(error);
  //     });

  //     loading.dismiss();
  //   });




  // }



  // addSizeToPsa($event) {

  //   let range_id = $event.srcElement.id;

  //   let ppe_range: size_range;
  //   let range: size_range;

  //   this.ppe.pe.size_ranges.forEach(sr => {

  //     if (sr.sizer_ID == range_id) {

  //       range = sr;
  //     }

  //   });

  //   this.ppe.size_ranges.forEach(sr => {

  //     if (sr.sizer_ID == range_id) {

  //       ppe_range = sr;
  //     }

  //   });



  //   for (var s of range.sizes) {
  //     if (s.size_ID == $event.detail.value) {

  //       if (ppe_range != null) {
  //         ppe_range.sizes[0] = s;
  //       }
  //       else {
  //         this.ppe.size_ranges.push(new size_range(s, range));
  //       }
  //     }
  //   }


  // }

  // addPsa() {
  //   //Wichtig nur eins von beiden mitgeben:
  //   this.ppe.stock_ID = 1;
  //   this.ppe.order_ID = null;

  //   let loading: HTMLIonLoadingElement;
  //   this.loadingController.create({
  //     spinner: "circles"
  //   }).then(res => {
  //     loading = res;
  //     loading.present();

  //     this.psaService.createPsa(this.ppe).then(res => {

  //       this.presentAlertConfirm();
  //     })
  //       .catch(error => {
  //         //Errorhandling here
  //         this.errorService.error(error);
  //       });

  //     loading.dismiss();
  //   });


  // }

  // async presentAlertConfirm() {

  //   const alert = await this.alertController.create({
  //     header: 'Die Psa wurde angelegt!',
  //     //message: '',
  //     buttons: [

  //       {
  //         text: 'Okay',
  //         handler: () => {
  //           this.router.navigate(['/users/ppe']);
  //         }
  //       }
  //     ]
  //   });

  //   await alert.present();
  // }

  // validation_messages = {
  //   'sn': [
  //     { type: 'required', message: 'Bitte eine gültige SN eintragen.' },
  //     { type: 'minlength', message: 'Die SN muss mindesten aus 2 Zeichen bestehen.' }
  //   ],
  //   'pn': [
  //     { type: 'required', message: 'Bitte eine gültige PN eintragen.' },
  //     { type: 'minlength', message: 'Die PN muss mindesten aus 2 Zeichen bestehen.' },
  //   ],
  //   'comment': [
  //     { type: 'maxlength', message: 'Der Kommentar darf maximal aus 150 Zeichen bestehen.' }
  //   ],
  //   'commissioningdate': [
  //   ],
  //   'state': [
  //     { type: 'maxlength', message: 'Der Status darf maximal aus 30 Zeichen bestehen.' }
  //   ],

  // }


}
