import { Component, OnInit } from '@angular/core';
// import { Router } from "@angular/router";
// import { PsaService } from "../../services/psa.service";
// import { PPE } from 'src/app/models/ppe';
// import { Events } from '@ionic/angular';
// import { AlertController } from '@ionic/angular';
// import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
// import { LoadingController } from "@ionic/angular";

@Component({
  selector: 'app-manage-psa',
  templateUrl: './manage-psa.page.html',
  styleUrls: ['./manage-psa.page.scss'],
})
export class ManagePsaPage implements OnInit {

  // ppes: PPE[];
  // active_ppe: PPE = <PPE>{};

  constructor(
    // private psaService: PsaService,
    // public router: Router,
    // private events: Events,
    // public alertController: AlertController,
    // private errorService: ErrorhandlingService,
    // private loadingController: LoadingController
  ) {
    // this.active_ppe = new PPE();
  }

  ngOnInit() {}



  // ionViewDidEnter() {
  //   this.getPsas();
  // }

  // async getPsas() {
  //   let loading: HTMLIonLoadingElement;
  //   this.loadingController.create({
  //     spinner: "circles"
  //   }).then(res => {
  //     loading = res;
  //     loading.present();

  //     this.psaService.getPsas(1).then(data => {

  //       this.ppes = data['ppes'];
  //       console.log(data);

  //     }).catch(error => {

  //       this.errorService.error(error);
  //     });

  //     loading.dismiss();
  //   });



  // }

  // public returnPsa(): PPE {
  //   return this.active_ppe;
  // }

  // public setActivePsa(psa: PPE) {
  //   this.active_ppe = psa;
  // }

  // showPpeDetails(index) {

  //   this.events.publish("showPsa", (this.ppes[index])); //um Employee zu aktualisieren (weil show Employee nur einmal manageEmployee.getEmployee macht)
  //   this.active_ppe = this.ppes[index];
  // }


  // updatePsa(id) {
  //   this.router.navigate(['/users/ppe/edit', id]);
  // }

  // addPsa() {
  //   this.router.navigate(['/users/ppe/add']);
  // }


  // deletePsa(id) {
  //   let ppe: PPE;

  //   this.ppes.forEach(p => {
  //     if (p.sn == id) {
  //       ppe = p;
  //     }
  //   });
  //   if (ppe.state == "Ausgemustert") {
  //     this.presentAlertConfirmDelete(ppe, id);
  //   }
  //   else {
  //     ppe.state = "Ausgemustert";

  //     this.psaService.updatePsa(ppe).then(res => {
  //       console.log(res);
  //     });
  //   }
  // }

  // async presentAlertConfirmDelete(ppe, id) {

  //   const alert = await this.alertController.create({
  //     header: 'Die Psa endgültig löschen?',
  //     //message: '',
  //     buttons: [
  //       {
  //         text: 'Abbrechen',
  //         role: 'cancel',
  //         cssClass: 'secondary',
  //         handler: (blah) => {

  //         }
  //       },
  //       {
  //         text: 'Okay',
  //         handler: () => {
  //           let loading: HTMLIonLoadingElement;
  //           this.loadingController.create({
  //             spinner: "circles"
  //           }).then(res => {
  //             loading = res;
  //             loading.present();

  //             this.psaService.deletePsa(id)
  //               .then(data => {
  //                 this.events.publish("showPsa");

  //                 this.ppes.splice(this.ppes.indexOf(ppe), 1);
  //                 if (this.ppes.length > 0) {
  //                   this.active_ppe = this.ppes[0];

  //                 }
  //                 this.router.navigate(['/users/ppe']);

  //               }).catch(error => {

  //                 this.errorService.error(error);
  //               });

  //             loading.dismiss();
  //           });

  //         }
  //       }
  //     ]
  //   });

  //   await alert.present();
  // }


}
