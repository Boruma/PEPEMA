import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-order-page',
  templateUrl: './edit-order.page.html',
  styleUrls: ['./edit-order.page.scss'],
})
export class EditOrderPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
