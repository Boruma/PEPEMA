import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-psa-page',
  templateUrl: './create-psa.page.html',
  styleUrls: ['./create-psa.page.scss'],
})
export class CreatePsaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
