import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-order-page',
  templateUrl: './show-order.page.html',
  styleUrls: ['./show-order.page.scss'],
})
export class ShowOrderPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
