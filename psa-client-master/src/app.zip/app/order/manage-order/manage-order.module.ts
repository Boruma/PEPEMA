import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';

import {IonicModule} from '@ionic/angular';

import {ManageOrderPage} from './manage-order.page';
import {ListOrdersComponentModule} from './../../components/order/list-orders/list-order-component.module';

const routes: Routes = [
    {
        path: '',
        component: ManageOrderPage
    },
    {path: 'add', loadChildren: '../add-order/add-order.module#AddOrderPageModule', data: {title: 'Neue Bestellung'}},
    {path: 'edit', loadChildren: '../edit-order/edit-order.module#EditOrderPageModule', data: {title: 'Bearbeiten'}},
    {path: 'show', loadChildren: '../show-order/show-order.module#ShowOrderPageModule', data: {title: 'Info'}},

];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        ListOrdersComponentModule,
        RouterModule.forChild(routes)
    ],
    declarations: [ManageOrderPage]
})
export class ManageOrderPageModule {
}
