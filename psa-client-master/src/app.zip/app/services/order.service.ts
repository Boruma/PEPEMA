import { Injectable } from '@angular/core';
import { Storage } from "@ionic/storage";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ProviderService } from './provider.service';
import { Order } from '../models/order';
import { Observable, of, throwError } from 'rxjs';
import { PPE } from '../models/ppe';

const TOKEN_KEY = 'auth-token';
@Injectable({
  providedIn: 'root'
})
export class OrderService {

  apiUrl: string = this.global.globalUrl + "/order";
  
  //for newOrder
  private newOrder: Order = null;
  private newPpes: PPE[] = null;
  public orderDataUpdatet: any = null;
  public ppesDataUpdatet: any = null;


  constructor(
    public http: HttpClient, 
    public global: ProviderService, 
    private storage: Storage
    ){ 
      console.log("construcotr orderservice");
      this.initObserver();
    }

    private initObserver(){
      this.orderDataUpdatet = Observable.create(observer => {
        observer.next(this.newOrder);
        // observer.complete();
      });
      this.ppesDataUpdatet = Observable.create(observer => {
        observer.next(this.newPpes);
        // observer.complete();
      });
    }

    private getNewOrder():Order{
      return this.newOrder;
    }

    public setNewOrder(order){
      if(this.newOrder == null){
        console.log(this.newOrder);
        this.newOrder = new Order();
      }
      console.log("setNewOrder in OrderService");
      this.newOrder = order;
      console.log(this.newOrder);
    }

    private getNewPpes():PPE[]{
      return this.newPpes;
    }

    public clearNewPpes(){
      if(this.newPpes != null){
      this.newPpes.length = 0;
      }

    }


    public addNewPpe(ppe:PPE){
      if(this.newPpes == null){
        this.newPpes = new Array<PPE>();
      }
      console.log("addPpe in OrderService");
      this.newPpes.push(ppe);
      console.log(this.newPpes);
    }





  //orderDelivered
  //Order commitedDeliveryDate auf aktuelles Datum setzen
  //benötigt nur die OrderID
  orderDelivered(id: Number): Promise<any> {
    return this.storage.get(TOKEN_KEY).then(res => {

      if (res) {
        const url = `${this.apiUrl}/delivered/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {};
        return this.http.put(url, postData, httpOption).toPromise();
      }
    });
  }

  //orderCommited
  //setzt orderdate auf aktuelles Datum
  //benötigt nur die OrderID
  //orderdate muss das Format yyyy-mm-dd haben
  //orderdate kann auch leer sein, dann wird aktuelles datum genutzt
  orderCommited(id: Number, orderdate: string): Promise<any> {
    return this.storage.get(TOKEN_KEY).then(res => {

      if (res) {
        const url = `${this.apiUrl}/commited/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          "orderdate": orderdate
        };
        return this.http.put(url, postData, httpOption).toPromise();
      }
    });
  }

  //CreateOrder
  //erstellt eine neue Order
  //commitedDeliveryDate muss leer sein!
  //erst Order erstellen und dann mit der zurückgegebenen ID die PPEs erstellen
  createOrder(order: Order): Promise<Order> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          "orderEnt": order
        };

        return this.http.post<Order>(this.apiUrl, postData, httpOption).toPromise();
      }
    });
  }

  //updateOrder
  //updated eine Order anhand der ID
  updateOrder(order: Order): Promise<Order> {
    console.log(order);
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          "orderEnt": order
        };

        return this.http.put<Order>(this.apiUrl, postData, httpOption).toPromise();
      }
    });
  }

  //getOrder
  //holt eine Order anhand der ID
  getOrder(id): Promise<Order> {
    return this.storage.get(TOKEN_KEY).then(res => {

      if (res) {
        const url = `${this.apiUrl}/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };

        return this.http.get<Order>(url, httpOption).toPromise();
      }
    });
  }

  //getOrdersOfSupplier
  //gibt alle Orders eines Suppliers zurück
  //die zu übergebende ID it die ID des Suppliers
  getOrdersOfSupplier(id): Promise<Order[]> {
    return this.storage.get(TOKEN_KEY).then(res => {

      if (res) {
        const url = `${this.apiUrl}/supplier/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };

        return this.http.get<Order[]>(url, httpOption).toPromise();
      }
    });
  }

  //getOrders
  //gibt alle Orders des Unternehmens zurück
  getOrders(): Promise<Order[]> {
    return this.storage.get(TOKEN_KEY).then(res => {
      console.log("getOrders() in OrderService");
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };

        return this.http.get<Order[]>(this.apiUrl, httpOption).toPromise();
      }
    });
  }

  //deleteOne
  //löscht eine Order anhand der ID
  deleteOrder(id) {
    return this.storage.get(TOKEN_KEY).then(res => {

      if (res) {
        const url = `${this.apiUrl}/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };

        return this.http.delete(url, httpOption).toPromise();
      }
    });
  }

  //deleteAll
  //löscht alle Orders einer Company
  deleteAllOrders() {
    return this.storage.get(TOKEN_KEY).then(res => {

      if (res) {
        const url = `${this.apiUrl}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };

        return this.http.delete(url, httpOption).toPromise();
      }
    });
  }

}
