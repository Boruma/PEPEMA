import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ProviderService } from "./provider.service";
import { Storage } from "@ionic/storage";
import { error } from 'util';
import { Pe } from "../models/pe";
import { Role } from "../models/role";

const TOKEN_KEY = 'auth-token';
@Injectable({
  providedIn: 'root'
})
export class PsatemplateService {
  psaTemplateUrl: string = this.global.globalUrl + '/pe';

  constructor(private http: HttpClient, public global: ProviderService, private storage: Storage) { }
  //creates a psatemplate via http post request
  createPsaTemplate(template: Pe): Promise<any> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };

        let postData = {
          "name": template.name,
          "supplier_ID": template.supplier.supplier_ID,
          "properties": template.properties,
          "size_range": template.size_ranges,
          "roles": template.roles,
          "supplItemId": template.supplItemID
        }
        return this.http.post(this.psaTemplateUrl, postData, httpOption).toPromise();
      }
    });
  }

  //gets the values of an psatemplate from the db
  getPsaTemplate(id): Promise<any> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const url = `${this.psaTemplateUrl}/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        return this.http.get(url, httpOption).toPromise();
      }
    });
  }

  //gets the values of all templates from the db   
  getPsaTemplates(): Promise<Pe[]> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        return this.http.get<Pe[]>(this.psaTemplateUrl, httpOption).toPromise();
      }
    });
  }


  deltePsaTemplate(id: number) {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const url = `${this.psaTemplateUrl}/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res

          })
        };
        return this.http.delete(url, httpOption).toPromise();
      }
    });
  }

  editPsaTemplate(template): Promise<any> {
    console.log(template);
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          "pe_ID": template.pe_ID,
          "name": template.name,
          "supplier_ID": template.supplier_ID,
          "properties": template.properties,
          "size_range": template.size_ranges,
          "roles": template.roles
        }
        return this.http.put(this.psaTemplateUrl, postData, httpOption).toPromise();
      }
    });
  }



  // get all roles from PE
  public getAllRolesFromPe(PeId: number) {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        const url = this.global.globalUrl + '/pe/roles/' + PeId;
        return this.http.get<Role[]>(url, httpOption).toPromise();
      }
    });
  }

  // get all roles
  public getAllRoles() {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          }
          )
        };
        const url = this.global.globalUrl + '/role';
        return this.http.get<Role[]>(url, httpOption).toPromise();
      }
    });
  }

  // add role to pe
  public addRole(PeId: number, roleId: number) {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
      
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          'role_ID': roleId,
          'pe_ID': PeId
        };
        // http://localhost/PSA/psa-server/public/api/role/assignEmployee?role_ID=6&employee_ID=1
        const url = this.global.globalUrl + '/pe/assignRole';
        return this.http.post(url, postData, httpOption).toPromise();
      }
    });
  }
  // removes a role from an pe
  public removeRole(PeId: number, roleId: number) {

    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          'role_ID': roleId,
          'pe_ID': PeId
        };
        // employee/unassignRole?role_ID=9&employee_ID=1
        const url = this.global.globalUrl + '/pe/unassignRole';
        return this.http.post(url, postData, httpOption).toPromise();
      }
    });
  }

}


