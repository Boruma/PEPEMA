import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProviderService {

  public globalUrl = "http://localhost/PSA/psa-server/public/api";
  constructor(){}
}
