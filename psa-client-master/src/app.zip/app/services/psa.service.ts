import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { ProviderService } from "./provider.service";
import { PPE } from 'src/app/models/ppe';
import { Property } from 'src/app/models/property';
import { size } from '../models/size';
import { Storage } from "@ionic/storage";


const TOKEN_KEY = 'auth-token';

@Injectable({
    providedIn: 'root'
})
export class PsaService {

    apiUrl: string = this.global.globalUrl + "/ppe";
    peUrl: string = this.global.globalUrl + "/pe";
    private ppeCount:number; 

    constructor(public http: HttpClient, public global: ProviderService, private storage: Storage) {
        this.ppeCount = 0;
     }

     public resetPpeCount(){
         this.ppeCount = 0;
     }

    //toChangePPEs: array von zu bearbeitenden PPEs
    //newPpe_IDs: array von neuen sn in gleicher Reihenfolge wie die PPEs
    //-> wichtig:   PPEs müssen mit dann richtiger SN übergeben werden, da die bisherige sn überarbeitet wird,
    //              da diese nur temporär war
    //die übergebenen PPEs werden dann als geliefert markiert und ins Lager gepackt
    deliveredPPEs(toChangePPEs: PPE[], newPPE_sn: string[]): Promise<any> {
        
        let counter = 0;
        toChangePPEs.forEach(value => {
            value['newSN'] = newPPE_sn[counter];
            counter++;
        });
        //console.log(toChangePPEs);
        return this.storage.get(TOKEN_KEY).then(res => {
            if (res) {
                const url = this.apiUrl + '/delivered';
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };
                let postData = {
                    "ppes": toChangePPEs
                };

                return this.http.post(url, postData, httpOption).toPromise();
            }
        });
    }

    getPes(): Promise<any> {
        return this.storage.get(TOKEN_KEY).then(res => {
            if (res) {
                const url = `${this.peUrl}`;
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };

                return this.http.get(url, httpOption).toPromise();
            }
        });
    }


    getProperites(template_id): Promise<Property[]> {

        var result = [
            {
                'property_ID': 1,
                'name': 'Waschen',
                'text': '',
                'minValue': 0,
                'maxValue': 30,
                'counter': 0,
                'date': null,
                'intervall': null,
                'type': "upValueRange",

                'created_at': null,
                'updated_at': null
            },
            {
                'property_ID': 2,
                'name': 'Lager',
                'text': '',
                'minValue': 0,
                'maxValue': 0,
                'counter': 0,
                'date': new Date(2019, 12, 15),
                'intervall': null,
                'type': "date",

                'created_at': null,
                'updated_at': null
            }
        ];
        return Promise.resolve(result);

    }

    getPsa(id): Promise<any> {
        return this.storage.get(TOKEN_KEY).then(res => {

            if (res) {
                const url = `${this.apiUrl}/${id}`;
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };

                return this.http.get(url, httpOption).toPromise();
            }
        });

    }

    getPe(id): Promise<any> {
        return this.storage.get(TOKEN_KEY).then(res => {

            if (res) {
                const url = `${this.peUrl}/${id}`;
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };

                return this.http.get(url, httpOption).toPromise();
            }
        });
    }

    getPsas(stock_id): Promise<PPE[]> {
        return this.storage.get(TOKEN_KEY).then(res => {

            if (res) {
                const url = this.apiUrl + '/all';
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };
                let postData = {
                    "stock_ID": stock_id
                };


                return this.http.post<PPE[]>(url, postData, httpOption).toPromise();
            }
        });

    }

    getPsasToEmployee(employee_id): Promise<PPE[]> {
        return this.storage.get(TOKEN_KEY).then(res => {
            if (res) {
                const url = this.apiUrl + '/all';
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };
                let postData = {
                    "employee_ID": employee_id
                };


                return this.http.post<PPE[]>(url, postData, httpOption).toPromise();
            }
        });
    }

    createPsa(psa: PPE): Promise<any> {

        //Prüfen, ob PPE für Order, dann sn automatisch ermitteln durch datum und uhrzeit
        if (psa.order_ID != null || psa.order_ID != 0) {
            let date: Date = new Date();
            let sn: string;

            sn = "order:" + psa.order_ID + "_" + date.getTime() + ++this.ppeCount;
            console.log(psa);
            console.log(sn);
            psa.sn = sn;
        }


        return this.storage.get(TOKEN_KEY).then(res => {

            if (res) {
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };
                let postData = {
                    "psa": psa
                };


                return this.http.post(this.apiUrl, postData, httpOption).toPromise();
            }
        });

    }

    updatePsa(psa: PPE): Promise<any> {
        return this.storage.get(TOKEN_KEY).then(res => {

            if (res) {
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };
                let postData = {
                    "psa": psa
                };


                return this.http.put(this.apiUrl, postData, httpOption).toPromise();
            }
        });

    }

    deletePsa(id) {
        return this.storage.get(TOKEN_KEY).then(res => {

            if (res) {
                const url = `${this.apiUrl}/${id}`;
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };

                return this.http.delete(url, httpOption).toPromise();
            }
        });
    }
}
