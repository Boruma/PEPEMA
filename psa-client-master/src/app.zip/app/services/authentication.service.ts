import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { BehaviorSubject } from 'rxjs';
import { Platform } from '@ionic/angular';
import { UserService } from "./user.service";
import { ProviderService } from "./provider.service";
import {Observable} from 'rxjs';

const TOKEN_KEY = 'auth-token';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  urlUser: string = this.global.globalUrl;
  authenticationState = new BehaviorSubject(false);

  constructor(private http: HttpClient, private storage: Storage, private plt: Platform, public global: ProviderService,
    private userService: UserService) {
    this.plt.ready().then(() => {
      this.checkToken();
    });
  }

  //Holt den auth-key aus dem Speicher und setzt den authenticationState anhand dessen
  checkToken() {
    this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        this.authenticationState.next(true);
      }
    })
  }

  isLoggedIn(): Promise<boolean> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if(res){
        return true;
      }else{
        return false;
      }
    });
  }

  logged(): boolean{
    return true;
  }

  //setzt authenticationState auf true und speichert Token ab
  login(authtoken: string) {
    return this.storage.set(TOKEN_KEY, authtoken).then(() => {
      this.authenticationState.next(true);
    });
  }

  //Löscht den auth-key aus Speicher und setzt authenticationState auf false
  logout() {
    return this.storage.remove(TOKEN_KEY).then(() => {
      this.authenticationState.next(false);
    });
  }

  //Gibt zurück, ob der User authentifiziert ist (für AuthGuard)
  isAuthenticated() {
    this.checkToken();
    //console.log(this.authenticationState.value);
    return this.authenticationState.value;
  }
}
