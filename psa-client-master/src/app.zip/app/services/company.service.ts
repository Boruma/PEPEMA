import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { ProviderService } from "./provider.service";
import { Storage } from "@ionic/storage";
import { Address } from "../models/address";
import { Company } from '../models/company';

const TOKEN_KEY = 'auth-token';

@Injectable({
    providedIn: 'root'
})

export class CompanyService {

    companyUrl: string = this.global.globalUrl + '/company';

    constructor(private http: HttpClient, public global: ProviderService, private storage: Storage) {
    }

    // creates a company
    createCompany(company: Company): Promise<any> {
        const httpOption = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        };
        let postData = {
            "company": company
        };
        return this.http.post(this.companyUrl, postData, httpOption).toPromise();
    }

    deleteEntity(id: number) {
        return this.storage.get(TOKEN_KEY).then(res => {
            if (res) {
                const url = `${this.companyUrl}/${id}`;
                const httpOption = {
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res
                    })
                };
                return this.http.delete(url, httpOption).toPromise();
                // bekommt einen 201 Status mit success: „Deleted Entity“ zurück
            }
        });
    }

    
}
