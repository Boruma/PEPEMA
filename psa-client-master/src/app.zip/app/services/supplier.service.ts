import { Injectable } from '@angular/core';
import { ProviderService } from './provider.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { Supplier } from '../models/Supplier';
import { PPE } from '../models/ppe';
import { Pe } from '../models/pe';

const TOKEN_KEY = 'auth-token';

@Injectable({
  providedIn: 'root'
})
export class SupplierService {

  supplierUrl: string = this.global.globalUrl + '/supplier';

  constructor(private http: HttpClient, public global: ProviderService, private storage: Storage) {
  }

  //gibt alle PEs eines Suppliers zurück
  getAllPEBySupplier(id): Promise<Pe[]> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const url = `${this.supplierUrl}/pes/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        return this.http.get<Pe[]>(url, httpOption).toPromise();
      }
    });
  }

  // creates a supplier
  createSupplier(supplier: Supplier): Promise<Supplier> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        console.log('Create Supplier: ');
        console.log(supplier);
        const postData = {

          'name': supplier.name,
          'email': supplier.email,
          'address':
          {
            "place": supplier.address.place,
            "street": supplier.address.street,
            "housenumber": supplier.address.housenumber,
            "postcode": supplier.address.postcode,
            "address_additional": supplier.address.address_additional
          }

        };
        return this.http.post<Supplier>(this.supplierUrl, postData, httpOption).toPromise();
      }
    });
  }

  createAndGetSupplier(supplier: Supplier): Promise<any> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          'name': supplier.name,
          'email': supplier.email,
          'address':
          {
            "place": supplier.address.place,
            "street": supplier.address.street,
            "housenumber": supplier.address.housenumber,
            "postcode": supplier.address.postcode,
            "address_additional": supplier.address.address_additional
          }

        };
        return this.http.post(this.supplierUrl, postData, httpOption).toPromise();
      }
    });


  }

  // gets the values of a supplier from the db
  getSupplier(id: number): Promise<Supplier> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const url = `${this.supplierUrl}/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        return this.http.get<Supplier>(url, httpOption).toPromise();
      }
    });

  }

  // gets the values of all suppliers from the db
  getSuppliers(): Promise<Supplier[]> {
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        return this.http.get<Supplier[]>(this.supplierUrl, httpOption).toPromise();
      }
    });




  }

  // Changes the values of supplier
  editSupplier(supplier: Supplier): Promise<Supplier> {
    console.log("Edit Supplier:");
    console.log(supplier);
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + res
          })
        };
        let postData = {
          'supplier_ID': supplier.supplier_ID,
          'name': supplier.name,
          'email': supplier.email,
          'address':
          {
            "place": supplier.address.place,
            "street": supplier.address.street,
            "housenumber": supplier.address.housenumber,
            "postcode": supplier.address.postcode,
            "address_additional": supplier.address.address_additional
          }

        };
        return this.http.put<Supplier>(this.supplierUrl, postData, httpOption).toPromise();
      }
    });
  }

  deleteSupplier(id: number) {
    console.log("delete Supplier: " + id);
    return this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        const url = `${this.supplierUrl}/${id}`;
        const httpOption = {
          headers: new HttpHeaders({
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + res
          })
        };
        return this.http.delete(url, httpOption).toPromise();
        // gets a 201 state with success: "deleted entity"
      }
    });
  }

  public copySupplier(supplier: Supplier): Supplier {
    const copy: Supplier = <Supplier>{};


    copy.supplier_ID = supplier.supplier_ID;
    copy.name = supplier.name;
    return copy;
  }
}
