import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class SetupService {

  public file: any;

 

  constructor() { }
}
