import { Component, OnInit } from '@angular/core';
import { User } from "../../models/user";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthenticationService } from "../../services/authentication.service";
import { Router } from "@angular/router";
import { LoadingController, MenuController, Platform } from "@ionic/angular";
import { UserService } from "../../services/user.service";
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { ToastService} from 'src/app/services/toast.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  loginForm: FormGroup;
  user: User = <User>{};
  attemptedSubmit: boolean = false;
  password: string;

  constructor(public fb: FormBuilder, private authService: AuthenticationService,
    private router: Router, private plt: Platform, private userService: UserService,
    private loadingController: LoadingController, private errorHandler: ErrorhandlingService,
    private menuCtrl: MenuController, private ts: ToastService) {
    //Defeniert die Validierung der Eingabefelder
    this.loginForm = fb.group({
      email: ['', [Validators.email, Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    //Schaut, ob bereits ein Benutzer existiert und wenn, dann loggt sich damit ein
    this.plt.ready().then(() => {
      this.loadUser();
    });
  }

  ngOnInit() {
  }

  //Deaktiviert das Menü
  /*ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }*/

  //Prüft ob User schon angemeldet ist
  loadUser() {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      //1. Informationen über User holen
      if (this.authService.isAuthenticated()) {
        //console.log("eingeloggt");
        this.router.navigate(['users/employees']);
        loading.dismiss();
      } else {
        loading.dismiss();
      }
    });
  }

  //Loggt User in Laravel ein, dann setzt lokale Daten, dann leitet weiter auf Home Seite
  loginUser() {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
    });
    //1. Login in Laravel
    this.userService.loginUser(this.user.email, this.password).then((res) => {
      //2. User Rechte geben
      this.authService.login(res.success.token).then(() => {
        //3. Loginprozess starten
        //console.log("eingeloggt");
        this.router.navigate(['users/employees']);
        loading.dismiss();
      }).catch((error) => {
        this.errorHandler.error(error);
        loading.dismiss();
      });
    }).catch(error => {
      if(error.status == 401){
        this.ts.presentToast("Email oder Passwort falsch!");
        this.password = "";
      }else{
        this.errorHandler.error(error);
      }
      loading.dismiss();
    });
  }

  //wird durch LogIn Button aufgerufen
  logIn() {
    this.attemptedSubmit = true;
    if (this.loginForm.valid) {
      this.loginUser();
    } else {
      this.markFieldsDirty();
    }
  }

  //Markiert die invaliden Eingabefelder
  markFieldsDirty() {
    for (var field in this.loginForm.controls) {
      this.loginForm.controls[field].markAsDirty();
    }
  }

  //Fehlermeldungen anhand der verschiedenen Fehler:
  validation_messages = {
    'email': [
      { type: 'required', message: 'Bitte geben Sie eine gültige Email Adresse ein.' },
      { type: 'email', message: 'Korrekte Email muss angegeben werden.' }
    ],
    'password': [
      { type: 'required', message: 'Bitte geben Sie ein gültiges Passwort ein.' },
      { type: 'minlength', message: 'Das Passwort muss mindestens 7 Zeichen lang sein.' },
    ]
  }

}
