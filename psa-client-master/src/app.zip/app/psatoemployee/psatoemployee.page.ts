import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms";
import { EmployeeService } from "../services/employee.service";
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { Address } from 'src/app/models/address';
import { Employee } from 'src/app/models/employee';
import { LoadingController, AlertController } from "@ionic/angular";
import { PsaService } from "../services/psa.service";
import { RoleService } from "../services/role.service";
import { PsatemplateService } from "../services/psatemplate.service";

import { PPE } from '../models/ppe';
import { Pe } from '../models/pe';

@Component({
  selector: 'app-psatoemployee',
  templateUrl: './psatoemployee.page.html',
  styleUrls: ['./psatoemployee.page.scss'],
})
export class PsatoemployeePage implements OnInit {
  private employees: Employee[];
  private psas: PPE[];
  private couter = 0;
  constructor(public formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private errorService: ErrorhandlingService,
    private loadingController: LoadingController,
    private psaService: PsaService,
    private psaTemplateServie: PsatemplateService,
    private alertCtrl: AlertController, ) { }

  ngOnInit() {

  }

  /*
    Viele Requests
    => Emploees mit Rollen zurückgeben
    => PPES mit rollen zurückgeben
    
  */
  ionViewWillEnter() {
    this.getAllEmployess();
  }


  getAllEmployess() {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.employeeService.getEmployees()
        .then(data => {
          this.couter++;
          this.employees = data;
          for (let employee of data) {
            this.employeeService.getAllRolesFromEmployee(employee.employee_ID)
              .then(data => {
                this.couter++;
                employee.roles = data;
              })
            this.psaService.getPsasToEmployee(employee.employee_ID).then(data => {
              employee.ppes = data['ppes'];
              for (let psa of employee.ppes) {
                this.psaService.getPe(psa.pe['pe_ID']).then(data => {
                  this.couter++;
                  psa.roles = data['roles'];
                })
              }
            }).catch(error => {
              console.log("zum Employee : " + employee.name + " gibt es keine PPES")
            })
          }

        }).catch(error => {
          //Errorhandling
          this.errorService.error(error);
          //  loading.dismiss();
        }).then(() => this.getAllPsas(loading));

    })
  }


  buildArray(employees, psas: PPE[], loadingt, loadingt2) {

    if (psas != undefined) {

      let result = [];
      for (let employee of employees) {
        employee.avippes = [];
        let firstArray = employee.roles;
        let secondArray;
        for (let i = 0; i < psas.length; i++) {
          this.psaService.getPe(psas[i].pe['pe_ID']).then(data => {
            psas[i].roles = data['roles'];
            this.couter++;
            //   console.log(this.couter);
          }).then(() => {
            secondArray = psas[i].roles;
            if (firstArray.filter(o => secondArray.some(({ role_ID, name }) => o.role_ID === role_ID && o.name === name)).length != 0) {
              // result.push(firstArray.filter(o => secondArray.some(({ role_ID, name }) => o.role_ID === role_ID && o.name === name)));
              employee.avippes.push(psas[i]);
            }
          })
        }
      }
      loadingt.dismiss();
      loadingt2.dismiss();
    }
  }

  getAllPsas(loadingt) {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      //1 => StockID
      this.psaService.getPsas(1)
        .then(data => {
          this.psas = data['ppes'];
          this.couter++;
          /*
          for (let psa of this.psas) {
            this.psaService.getPe(psa.template['pe_ID']).then(data => {
              psa.roles = data['roles'];
              this.couter++;
            })
          }*/
          //  loadingt.dismiss();
          //    loading.dismiss();
        }).catch(error => {
          //Errorhandling
          this.errorService.error(error);
          loading.dismiss();
          loadingt.dismiss();
        }).then(() => {

          this.buildArray(this.employees, this.psas, loading, loadingt);
        })
    });
  }



  assignone(employee: Employee, ppe: PPE) {
    if (employee.ppes === undefined) {
      employee.ppes = [];
    };
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.employeeService.assignOne(employee, ppe)
        .then(data => {
          let indexEmployee = this.employees.findIndex(emp => emp.employee_ID === employee.employee_ID);
          this.employees[indexEmployee].ppes.push(ppe);
          for (let employee2 of this.employees) {
            let index = employee2.avippes.findIndex(order => order.sn === ppe.sn);
            employee2.avippes.splice(index, 1);
          }
          loading.dismiss();
        })
        .catch(error => {
          //Errorhandling
          this.errorService.error(error);
          loading.dismiss();
        });
    });
  }

  unassignone(employee, stock, ppe: PPE) {
    let loading: HTMLIonLoadingElement;
    this.loadingController.create({
      spinner: "circles"
    }).then(res => {
      loading = res;
      loading.present();
      this.employeeService.unassignOne(stock, ppe)
        .then(data => {
          let indexEmployee = this.employees.findIndex(emp => emp.employee_ID === employee.employee_ID);
          let index = employee.ppes.findIndex(search => search.sn === ppe.sn);
          this.employees[indexEmployee].ppes.splice(index, 1);
          for (let Employee of this.employees) {
            for (let role of ppe.roles) {
              if (Employee.roles.some(e => e.role_ID === role.role_ID)) {
                Employee.avippes.push(ppe);
              }
            }
          }
          loading.dismiss();
        })
        .catch(error => {
          //Errorhandling
          this.errorService.error(error);
          loading.dismiss();
        })
    });
  }
  async presentAlertConfirmUnassignOne(employee: Employee, stock, ppe: PPE) {
    const alert = await this.alertCtrl.create({
      header: 'Schanlone löschen',
      message: '<strong>' + ppe.sn + '</strong> wirklich von <strong>' + employee.name + '</strong> entfernen?',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {

          }
        }, {
          text: 'Okay',
          handler: () => {
            this.unassignone(employee, stock, ppe);
          }
        }
      ]
    });
    await alert.present();
    let result = await alert.onDidDismiss();
  }
  async presentAlertConfirmDelte(employee: Employee, stock, ppe: PPE) {
    const alert = await this.alertCtrl.create({
      header: 'Schanlone löschen',
      message: '<strong>' + ppe.sn + '</strong> wirklich löschen?',
      buttons: [
        {
          text: 'Abbrechen',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {

          }
        }, {
          text: 'Okay',
          handler: () => {
            this.employeeService.unassignOne(stock, ppe);
            this.psaService.deletePsa(ppe.sn);
          }
        }
      ]
    });
    await alert.present();
    let result = await alert.onDidDismiss();
  }


}
