import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';

import {IonicModule} from '@ionic/angular';

import {DesignTemplatePage} from './design-template.page';

const routes: Routes = [
    {
        path: '',
        component: DesignTemplatePage
    }
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        RouterModule.forChild(routes),
    ],
    declarations: [DesignTemplatePage]
})
export class DesignTemplatePageModule {
}
