import {Component, OnInit} from '@angular/core';
import {Role} from '../models/role';

@Component({
    selector: 'app-design-template',
    templateUrl: './design-template.page.html',
    styleUrls: ['./design-template.page.scss'],
})
export class DesignTemplatePage implements OnInit {

    placeholder: string;

    constructor() {
        this.placeholder = 'Ihre Eingabe...';
    }

    ngOnInit() {
    }

    //Array to fill the Checkbox List
    public checkboxOptions = [
        {id: 0, val: 'Checkbox 1', isChecked: true},
        {id: 1, val: 'Checkbox 2', isChecked: false},
        {id: 2, val: 'Checkbox 3', isChecked: false}
    ];

    //Array to fill the Dropdown List
    public dropdownOptions = [
        {id: 0, val: 'Dropdown 1'},
        {id: 1, val: 'Dropdown 2'},
        {id: 2, val: 'Dropdown 3'}
    ];

    //change this for the default value of the Dropdown
    public dropdownDefault = 1;

    //Function that is called when the value of the dropDown changes
    public dropdownFunction($event) {
        console.log($event.detail.value);
    }
}
