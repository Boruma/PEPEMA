import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SetupService } from '../../services/setup.service';
import { PsatemplateService } from '../../services/psatemplate.service';
import { RoleService } from '../../services/role.service';
import { SupplierService } from '../../services/supplier.service';
import { ErrorhandlingService } from 'src/app/services/errorhandling.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Supplier } from '../../models/Supplier';
import { Address } from 'src/app/models/address';
import { LoadingController } from "@ionic/angular";


@Component({
  selector: 'app-supplier-setup',
  templateUrl: './supplier-setup.page.html',
  styleUrls: ['./supplier-setup.page.scss'],
})
export class SupplierSetupPage implements OnInit {

  file: any;

  supplierForm: FormGroup;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private setupService: SetupService,
    private templateService: PsatemplateService,
    private roleService: RoleService,
    private supplierService: SupplierService,
    private errorService: ErrorhandlingService,
    private formBuilder: FormBuilder,
    private loadingController: LoadingController, ) {

    this.file = setupService.file;
    console.log(setupService.file);

    this.file.templates.forEach(pe => {
      pe.supplier.address = new Address();
    });

    this.supplierForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
      email: ['', [Validators.email, Validators.minLength(5), Validators.maxLength(40),
      Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      suplID: ['', [Validators.minLength(2), Validators.maxLength(11)]],
      street: ['', [Validators.minLength(2), Validators.maxLength(20)]],
      housenumber: ['', [Validators.minLength(1), Validators.maxLength(10)]],
      postcode: ['', [Validators.minLength(2), Validators.maxLength(10)]],
      place: ['', [Validators.minLength(2), Validators.maxLength(30)]],
      address_additional: ['', [Validators.minLength(2), Validators.maxLength(30)]]
    });

  }

  validation_messages = {
    email: [
      { type: 'required', message: 'Bitte eine gültige Email eintragen.' },
      { type: 'email', message: 'Die Email Adresse muss gültig sein.' },
      { type: 'pattern', message: 'Die Email Adresse muss folgendes Format haben: xxxx@xx.xx' },
      { type: 'maxlength', message: 'Die Email darf maximal aus 40 Zeichen bestehen.' }
    ],
    name: [
      { type: 'required', message: 'Bitte ein gültigen Namen eintragen.' },
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 20 Zeichen bestehen.' }
    ],
    suplID: [
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 11 Zeichen bestehen.' }
    ],
    street: [
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 20 Zeichen bestehen.' }
    ],
    housenumber: [
      { type: 'minlength', message: 'Der Name muss mindesten aus 1 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 10 Zeichen bestehen.' }
    ],
    postcode: [
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 10 Zeichen bestehen.' }
    ],
    place: [
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 30 Zeichen bestehen.' }
    ],
    address_additional: [
      { type: 'minlength', message: 'Der Name muss mindesten aus 2 Zeichen bestehen.' },
      { type: 'maxlength', message: 'Der Name darf maximal aus 30 Zeichen bestehen.' }
    ]
  }

  ngOnInit() {
  }

  public setup() {
    if (this.supplierForm.valid) {
      console.log(this.file);

      //Rollen anlegen
      let loading: HTMLIonLoadingElement;
      this.loadingController.create({
        spinner: "circles"
      }).then(res => {
        loading = res;
        loading.present();

        this.file.roles.forEach(role => {
          this.roleService.createRole(role.name).then(res => {
            console.log(res);
          })
            .catch(error => {
              //Errorhandling here
              this.errorService.error(error);
            });
        });







        //PEs anlegen
        this.file.templates.forEach(pe => {

          this.supplierService.createSupplier(pe.supplier).then(res => {
            pe.supplier.supplier_ID = res.supplier_ID;
            this.templateService.createPsaTemplate(pe).then(res => {
            })
              .catch(error => {
                //Errorhandling here
                this.errorService.error(error);
              });
          }).catch(error => {
            //Errorhandling here
            this.errorService.error(error);
          });


        });

        

        loading.dismiss();
      });
    }
  }

}
